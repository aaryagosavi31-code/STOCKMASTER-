import { db } from "./db";
import { users, warehouses, inventoryItems } from "@shared/schema";

async function seed() {
  console.log("Seeding database...");

  const [warehouse1, warehouse2] = await db
    .insert(warehouses)
    .values([
      { name: "Warehouse A", location: "North District", capacity: 10000 },
      { name: "Warehouse B", location: "South District", capacity: 8000 },
    ])
    .returning();

  const [user1] = await db
    .insert(users)
    .values([
      {
        id: "demo-user-id",
        email: "john@example.com",
        firstName: "John",
        lastName: "Doe",
        role: "inventory_manager",
      },
    ])
    .returning();

  await db.insert(inventoryItems).values([
    {
      sku: "ELC-001",
      name: "Wireless Mouse",
      category: "Electronics",
      quantity: 145,
      minStock: 50,
      price: "29.99",
      warehouseId: warehouse1.id,
      location: "Warehouse A - Shelf 12",
    },
    {
      sku: "ELC-002",
      name: "USB-C Cable",
      category: "Electronics",
      quantity: 23,
      minStock: 30,
      price: "12.99",
      warehouseId: warehouse1.id,
      location: "Warehouse A - Shelf 8",
    },
    {
      sku: "FUR-001",
      name: "Office Chair",
      category: "Furniture",
      quantity: 0,
      minStock: 10,
      price: "249.99",
      warehouseId: warehouse2.id,
      location: "Warehouse B - Section 3",
    },
    {
      sku: "STA-001",
      name: "Notebook Set",
      category: "Stationery",
      quantity: 432,
      minStock: 100,
      price: "8.99",
      warehouseId: warehouse1.id,
      location: "Warehouse A - Shelf 15",
    },
    {
      sku: "ELC-003",
      name: "Mechanical Keyboard",
      category: "Electronics",
      quantity: 78,
      minStock: 25,
      price: "89.99",
      warehouseId: warehouse1.id,
      location: "Warehouse A - Shelf 12",
    },
    {
      sku: "FUR-002",
      name: "Desk Lamp",
      category: "Furniture",
      quantity: 67,
      minStock: 20,
      price: "45.99",
      warehouseId: warehouse2.id,
      location: "Warehouse B - Section 1",
    },
  ]);

  console.log("Database seeded successfully!");
  process.exit(0);
}

seed().catch((err) => {
  console.error("Error seeding database:", err);
  process.exit(1);
});
