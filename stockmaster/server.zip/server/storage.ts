import {
  type User,
  type UpsertUser,
  type InventoryItem,
  type InsertInventoryItem,
  type Transaction,
  type InsertTransaction,
  type Warehouse,
  type InsertWarehouse,
  type Alert,
  type InsertAlert,
  type Order,
  type InsertOrder,
  users,
  inventoryItems,
  transactions,
  warehouses,
  alerts,
  orders,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, sql } from "drizzle-orm";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;

  getWarehouses(): Promise<Warehouse[]>;
  getWarehouse(id: string): Promise<Warehouse | undefined>;
  createWarehouse(warehouse: InsertWarehouse): Promise<Warehouse>;

  getInventoryItems(): Promise<InventoryItem[]>;
  getInventoryItem(id: string): Promise<InventoryItem | undefined>;
  getInventoryItemBySku(sku: string): Promise<InventoryItem | undefined>;
  createInventoryItem(item: InsertInventoryItem): Promise<InventoryItem>;
  updateInventoryItem(id: string, item: Partial<InsertInventoryItem>): Promise<InventoryItem | undefined>;
  deleteInventoryItem(id: string): Promise<void>;
  updateItemQuantity(id: string, quantityChange: number): Promise<InventoryItem | undefined>;

  getTransactions(limit?: number): Promise<(Transaction & { itemName: string; userName: string })[]>;
  getTransactionsByItem(itemId: string): Promise<Transaction[]>;
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;

  getAlerts(): Promise<(Alert & { itemName: string; sku: string; currentStock: number; minStock: number })[]>;
  createAlert(alert: InsertAlert): Promise<Alert>;
  resolveAlert(id: string): Promise<void>;
  checkAndCreateAlerts(): Promise<void>;

  getAnalytics(): Promise<{
    totalItems: number;
    totalValue: number;
    lowStockCount: number;
    outOfStockCount: number;
  }>;

  getOrders(): Promise<(Order & { itemName: string })[]>;
  createOrder(order: InsertOrder): Promise<Order>;
}

export class DbStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
    return result[0];
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async getWarehouses(): Promise<Warehouse[]> {
    return await db.select().from(warehouses);
  }

  async getWarehouse(id: string): Promise<Warehouse | undefined> {
    const result = await db.select().from(warehouses).where(eq(warehouses.id, id)).limit(1);
    return result[0];
  }

  async createWarehouse(warehouse: InsertWarehouse): Promise<Warehouse> {
    const result = await db.insert(warehouses).values(warehouse).returning();
    return result[0];
  }

  async getInventoryItems(): Promise<InventoryItem[]> {
    return await db.select().from(inventoryItems).orderBy(desc(inventoryItems.lastUpdated));
  }

  async getInventoryItem(id: string): Promise<InventoryItem | undefined> {
    const result = await db.select().from(inventoryItems).where(eq(inventoryItems.id, id)).limit(1);
    return result[0];
  }

  async getInventoryItemBySku(sku: string): Promise<InventoryItem | undefined> {
    const result = await db.select().from(inventoryItems).where(eq(inventoryItems.sku, sku)).limit(1);
    return result[0];
  }

  async createInventoryItem(item: InsertInventoryItem): Promise<InventoryItem> {
    const result = await db.insert(inventoryItems).values(item).returning();
    return result[0];
  }

  async updateInventoryItem(id: string, item: Partial<InsertInventoryItem>): Promise<InventoryItem | undefined> {
    const result = await db
      .update(inventoryItems)
      .set({ ...item, lastUpdated: new Date() })
      .where(eq(inventoryItems.id, id))
      .returning();
    return result[0];
  }

  async deleteInventoryItem(id: string): Promise<void> {
    await db.delete(inventoryItems).where(eq(inventoryItems.id, id));
  }

  async updateItemQuantity(id: string, quantityChange: number): Promise<InventoryItem | undefined> {
    const item = await this.getInventoryItem(id);
    if (!item) return undefined;

    const newQuantity = item.quantity + quantityChange;
    return await this.updateInventoryItem(id, { quantity: newQuantity });
  }

  async getTransactions(limit: number = 50): Promise<(Transaction & { itemName: string; userName: string })[]> {
    const result = await db
      .select({
        id: transactions.id,
        itemId: transactions.itemId,
        type: transactions.type,
        quantity: transactions.quantity,
        userId: transactions.userId,
        reference: transactions.reference,
        fromLocation: transactions.fromLocation,
        toLocation: transactions.toLocation,
        timestamp: transactions.timestamp,
        itemName: inventoryItems.name,
        userName: users.name,
      })
      .from(transactions)
      .leftJoin(inventoryItems, eq(transactions.itemId, inventoryItems.id))
      .leftJoin(users, eq(transactions.userId, users.id))
      .orderBy(desc(transactions.timestamp))
      .limit(limit);

    return result.map((row) => ({
      ...row,
      itemName: row.itemName || "Unknown Item",
      userName: row.userName || "Unknown User",
    }));
  }

  async getTransactionsByItem(itemId: string): Promise<Transaction[]> {
    return await db.select().from(transactions).where(eq(transactions.itemId, itemId)).orderBy(desc(transactions.timestamp));
  }

  async createTransaction(transaction: InsertTransaction): Promise<Transaction> {
    const result = await db.insert(transactions).values(transaction).returning();
    return result[0];
  }

  async getAlerts(): Promise<(Alert & { itemName: string; sku: string; currentStock: number; minStock: number })[]> {
    const result = await db
      .select({
        id: alerts.id,
        itemId: alerts.itemId,
        type: alerts.type,
        severity: alerts.severity,
        resolved: alerts.resolved,
        createdAt: alerts.createdAt,
        itemName: inventoryItems.name,
        sku: inventoryItems.sku,
        currentStock: inventoryItems.quantity,
        minStock: inventoryItems.minStock,
      })
      .from(alerts)
      .leftJoin(inventoryItems, eq(alerts.itemId, inventoryItems.id))
      .where(eq(alerts.resolved, 0))
      .orderBy(desc(alerts.createdAt));

    return result.map((row) => ({
      ...row,
      itemName: row.itemName || "Unknown Item",
      sku: row.sku || "UNKNOWN",
      currentStock: row.currentStock || 0,
      minStock: row.minStock || 0,
    }));
  }

  async createAlert(alert: InsertAlert): Promise<Alert> {
    const result = await db.insert(alerts).values(alert).returning();
    return result[0];
  }

  async resolveAlert(id: string): Promise<void> {
    await db.update(alerts).set({ resolved: 1 }).where(eq(alerts.id, id));
  }

  async checkAndCreateAlerts(): Promise<void> {
    const items = await this.getInventoryItems();

    for (const item of items) {
      const existingAlerts = await db
        .select()
        .from(alerts)
        .where(and(eq(alerts.itemId, item.id), eq(alerts.resolved, 0)))
        .limit(1);

      if (existingAlerts.length > 0) continue;

      if (item.quantity === 0) {
        await this.createAlert({
          itemId: item.id,
          type: "out_of_stock",
          severity: "high",
          resolved: 0,
        });
      } else if (item.quantity <= item.minStock) {
        await this.createAlert({
          itemId: item.id,
          type: "low_stock",
          severity: item.quantity <= item.minStock * 0.5 ? "medium" : "low",
          resolved: 0,
        });
      }
    }
  }

  async getAnalytics(): Promise<{
    totalItems: number;
    totalValue: number;
    lowStockCount: number;
    outOfStockCount: number;
  }> {
    const items = await this.getInventoryItems();

    const totalItems = items.reduce((sum, item) => sum + item.quantity, 0);
    const totalValue = items.reduce((sum, item) => sum + item.quantity * parseFloat(item.price), 0);
    const lowStockCount = items.filter((item) => item.quantity > 0 && item.quantity <= item.minStock).length;
    const outOfStockCount = items.filter((item) => item.quantity === 0).length;

    return {
      totalItems,
      totalValue,
      lowStockCount,
      outOfStockCount,
    };
  }

  async getOrders(): Promise<Order[]> {
    return await db.select().from(orders).orderBy(desc(orders.createdAt));
  }

  async createOrder(order: InsertOrder): Promise<Order> {
    const result = await db.insert(orders).values(order).returning();
    return result[0];
  }
}

export const storage = new DbStorage();
