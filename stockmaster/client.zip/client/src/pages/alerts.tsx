import { useQuery, useMutation } from "@tanstack/react-query";
import { AlertList, Alert } from "@/components/alert-list";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { formatDistanceToNow } from "date-fns";

interface AlertData {
  id: string;
  type: string;
  severity: string;
  itemName: string;
  sku: string;
  currentStock: number;
  minStock: number;
  createdAt: string;
}

export default function Alerts() {
  const { toast } = useToast();

  const { data: alertsData = [], isLoading, error } = useQuery<AlertData[]>({
    queryKey: ["/api/alerts"],
  });

  if (error && isUnauthorizedError(error)) {
    window.location.href = "/api/login";
  }

  const resolveMutation = useMutation({
    mutationFn: async (alertId: string) => {
      await apiRequest("POST", `/api/alerts/${alertId}/resolve`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/alerts"] });
      toast({
        title: "Reorder initiated",
        description: "Purchase order has been created.",
      });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        window.location.href = "/api/login";
      } else {
        toast({
          title: "Error",
          description: "Failed to resolve alert. Please try again.",
          variant: "destructive",
        });
      }
    },
  });

  const dismissMutation = useMutation({
    mutationFn: async (alertId: string) => {
      await apiRequest("POST", `/api/alerts/${alertId}/resolve`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/alerts"] });
      toast({
        title: "Alert dismissed",
        description: "Alert has been dismissed.",
      });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        window.location.href = "/api/login";
      } else {
        toast({
          title: "Error",
          description: "Failed to dismiss alert. Please try again.",
          variant: "destructive",
        });
      }
    },
  });

  const handleResolve = (alert: Alert) => {
    resolveMutation.mutate(alert.id);
  };

  const handleDismiss = (alert: Alert) => {
    dismissMutation.mutate(alert.id);
  };

  const alerts: Alert[] = (alertsData || []).map((a: AlertData) => ({
    id: a.id,
    type: a.type as "low_stock" | "out_of_stock" | "reorder",
    itemName: a.itemName,
    sku: a.sku,
    currentStock: a.currentStock,
    minStock: a.minStock,
    timestamp: formatDistanceToNow(new Date(a.createdAt), { addSuffix: true }),
    severity: a.severity as "high" | "medium" | "low",
  }));

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-semibold">Stock Alerts</h1>
          <p className="text-muted-foreground">
            Monitor and manage low stock and out-of-stock alerts
          </p>
        </div>
        <div className="text-center py-8">Loading alerts...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold">Stock Alerts</h1>
        <p className="text-muted-foreground">
          Monitor and manage low stock and out-of-stock alerts
        </p>
      </div>

      <AlertList alerts={alerts} onResolve={handleResolve} onDismiss={handleDismiss} />
    </div>
  );
}
