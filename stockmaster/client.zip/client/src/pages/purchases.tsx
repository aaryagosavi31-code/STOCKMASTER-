import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  ShoppingCart,
  User,
  Phone,
  Mail,
  MapPin,
  Banknote,
  Calendar,
  Package,
  Building2,
  Plus,
  Clock,
} from "lucide-react";
import { formatCurrency } from "@/lib/currency";
import { CreatePurchaseOrderDialog } from "@/components/create-purchase-order";

const purchaseOrders = [
  {
    id: "PO001",
    date: "2024-11-22",
    status: "confirmed",
    quantity: 100,
    amount: 50000,
    items: "Electronics - Smart Devices",
    deliveryDate: "2024-12-05",
    deliveryLocation: "Mumbai, Maharashtra",
    supplier: {
      name: "Rahul Electronics Co.",
      company: "Rahul Electronics Co. Ltd.",
      email: "sales@rahulelectronics.com",
      phone: "+91-98765-43210",
      contactPerson: "Rajesh Patel",
    },
    bank: {
      accountName: "Rahul Electronics Co. Ltd.",
      accountNumber: "1234567890123456",
      ifsc: "HDFC0001234",
      bankName: "HDFC Bank",
    },
    location: {
      address: "456 Supplier Park",
      city: "Bangalore",
      state: "Karnataka",
      pincode: "560034",
    },
    paymentTerms: "50% advance, 50% on delivery",
    specifications: "High quality, certified, warranty included",
  },
  {
    id: "PO002",
    date: "2024-11-20",
    status: "pending",
    quantity: 75,
    amount: 35000,
    items: "Furniture - Office Chairs",
    deliveryDate: "2024-12-10",
    deliveryLocation: "Delhi, NCR",
    supplier: {
      name: "Kumar Furniture Suppliers",
      company: "Kumar Furniture Suppliers Pvt Ltd.",
      email: "orders@kumarfurniture.com",
      phone: "+91-98123-45678",
      contactPerson: "Amit Kumar",
    },
    bank: {
      accountName: "Kumar Furniture Suppliers Pvt Ltd.",
      accountNumber: "9876543210987654",
      ifsc: "ICIC0000456",
      bankName: "ICICI Bank",
    },
    location: {
      address: "789 Industrial Zone",
      city: "Jaipur",
      state: "Rajasthan",
      pincode: "302006",
    },
    paymentTerms: "Net 30 days",
    specifications: "Ergonomic design, eco-friendly materials",
  },
  {
    id: "PO003",
    date: "2024-11-18",
    status: "shipped",
    quantity: 200,
    amount: 80000,
    items: "Appliances - Kitchen Equipment",
    deliveryDate: "2024-12-01",
    deliveryLocation: "Bangalore, Karnataka",
    supplier: {
      name: "Tech Appliances India",
      company: "Tech Appliances India Pvt Ltd.",
      email: "wholesale@techappliances.com",
      phone: "+91-98456-78901",
      contactPerson: "Priya Verma",
    },
    bank: {
      accountName: "Tech Appliances India Pvt Ltd.",
      accountNumber: "5555666677778888",
      ifsc: "AXIS0000789",
      bankName: "Axis Bank",
    },
    location: {
      address: "123 Factory Road",
      city: "Hyderabad",
      state: "Telangana",
      pincode: "500032",
    },
    paymentTerms: "40% advance, 60% before shipping",
    specifications: "ISO certified, bulk discount applied",
  },
  {
    id: "PO004",
    date: "2024-11-15",
    status: "delivered",
    quantity: 50,
    amount: 22000,
    items: "Electronics - Cables & Accessories",
    deliveryDate: "2024-11-28",
    deliveryLocation: "Hyderabad, Telangana",
    supplier: {
      name: "Global Tech Exports",
      company: "Global Tech Exports Ltd.",
      email: "b2b@globaltech.com",
      phone: "+91-98765-12345",
      contactPerson: "Vikram Singh",
    },
    bank: {
      accountName: "Global Tech Exports Ltd.",
      accountNumber: "1111222233334444",
      ifsc: "BKID0001111",
      bankName: "Bank of India",
    },
    location: {
      address: "456 Export Complex",
      city: "Chennai",
      state: "Tamil Nadu",
      pincode: "600001",
    },
    paymentTerms: "100% advance payment",
    specifications: "Certified, vacuum packed, fast shipping",
  },
  {
    id: "PO005",
    date: "2024-11-10",
    status: "delivered",
    quantity: 120,
    amount: 45000,
    items: "Furniture - Storage Cabinets",
    deliveryDate: "2024-11-25",
    deliveryLocation: "Pune, Maharashtra",
    supplier: {
      name: "Premium Logistics & Supplies",
      company: "Premium Logistics & Supplies Co.",
      email: "procurement@premiumlogistics.com",
      phone: "+91-98901-23456",
      contactPerson: "Suresh Rao",
    },
    bank: {
      accountName: "Premium Logistics & Supplies Co.",
      accountNumber: "7777888899990000",
      ifsc: "UTIB0001234",
      bankName: "Axis Bank",
    },
    location: {
      address: "789 Supply Avenue",
      city: "Surat",
      state: "Gujarat",
      pincode: "395002",
    },
    paymentTerms: "Net 15 days",
    specifications: "Customizable options, premium quality",
  },
];

interface PurchaseOrder {
  id: string;
  date: string;
  status: string;
  quantity: number;
  amount: number;
  items: string;
  deliveryDate: string;
  deliveryLocation: string;
  supplier: {
    name: string;
    company: string;
    email: string;
    phone: string;
    contactPerson: string;
  };
  bank: {
    accountName: string;
    accountNumber: string;
    ifsc: string;
    bankName: string;
  };
  location: {
    address: string;
    city: string;
    state: string;
    pincode: string;
  };
  paymentTerms: string;
  specifications: string;
}

export default function Purchases() {
  const [currency] = useState(() => localStorage.getItem("currency") || "INR");
  const [customOrders, setCustomOrders] = useState<PurchaseOrder[]>([]);
  const [selectedOrder, setSelectedOrder] = useState<PurchaseOrder | null>(null);
  const [statusFilter, setStatusFilter] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");

  // Combine custom and sample orders
  const allOrders = [...purchaseOrders, ...customOrders];

  const filteredOrders = allOrders.filter((order) => {
    const matchesStatus = statusFilter === "all" || order.status === statusFilter;
    const matchesSearch =
      order.supplier.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.items.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  const handleOrderCreated = (newOrder: any) => {
    setCustomOrders([...customOrders, newOrder]);
  };

  const totalAmount = allOrders.reduce((sum, o) => sum + o.amount, 0);
  const deliveredCount = allOrders.filter((o) => o.status === "delivered").length;
  const pendingCount = allOrders.filter((o) => o.status === "pending").length;
  const totalItems = allOrders.reduce((sum, o) => sum + o.quantity, 0);

  const getStatusColor = (status: string) => {
    switch (status) {
      case "delivered":
        return "bg-green-50 text-green-700 border-green-200 dark:bg-green-950 dark:text-green-50 dark:border-green-800";
      case "shipped":
        return "bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-950 dark:text-blue-50 dark:border-blue-800";
      case "confirmed":
        return "bg-purple-50 text-purple-700 border-purple-200 dark:bg-purple-950 dark:text-purple-50 dark:border-purple-800";
      case "pending":
        return "bg-yellow-50 text-yellow-700 border-yellow-200 dark:bg-yellow-950 dark:text-yellow-50 dark:border-yellow-800";
      default:
        return "bg-gray-50 text-gray-700 border-gray-200 dark:bg-gray-950 dark:text-gray-50 dark:border-gray-800";
    }
  };

  const getDaysUntilDelivery = (deliveryDate: string) => {
    const today = new Date();
    const delivery = new Date(deliveryDate);
    const diffTime = delivery.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-semibold">Purchase Orders</h1>
          <p className="text-muted-foreground">
            Manage supplier purchases and order shipments
          </p>
        </div>
        <CreatePurchaseOrderDialog onOrderCreated={handleOrderCreated} />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Orders</p>
                <p className="text-2xl font-bold">{allOrders.length}</p>
              </div>
              <ShoppingCart className="h-8 w-8 text-primary opacity-70" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Cost</p>
                <p className="text-2xl font-bold">{formatCurrency(totalAmount, currency)}</p>
              </div>
              <Banknote className="h-8 w-8 text-primary opacity-70" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Units</p>
                <p className="text-2xl font-bold">{totalItems}</p>
              </div>
              <Package className="h-8 w-8 text-primary opacity-70" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Delivered</p>
                <p className="text-2xl font-bold text-green-600">{deliveredCount}</p>
              </div>
              <div className="text-sm text-muted-foreground">Received</div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Search & Filter</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-4 flex-wrap">
            <div className="flex-1 min-w-[200px]">
              <Label htmlFor="search" className="text-sm mb-2 block">
                Search by Supplier or Items
              </Label>
              <Input
                id="search"
                placeholder="Search supplier name, item type, or order ID..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                data-testid="input-search-purchases"
              />
            </div>
            <div className="w-[200px]">
              <Label htmlFor="status" className="text-sm mb-2 block">
                Status
              </Label>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger id="status" data-testid="select-purchase-status">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Orders</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="confirmed">Confirmed</SelectItem>
                  <SelectItem value="shipped">Shipped</SelectItem>
                  <SelectItem value="delivered">Delivered</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 gap-4">
        {filteredOrders.map((order) => {
          const daysLeft = getDaysUntilDelivery(order.deliveryDate);
          return (
            <Card
              key={order.id}
              className="hover-elevate cursor-pointer"
              onClick={() => setSelectedOrder(order)}
              data-testid={`card-purchase-${order.id}`}
            >
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      <span>{order.supplier.company}</span>
                      <Badge className="text-xs" variant="outline">
                        {order.id}
                      </Badge>
                    </CardTitle>
                    <CardDescription className="flex items-center gap-2 mt-2">
                      <Calendar className="h-4 w-4" />
                      Order: {new Date(order.date).toLocaleDateString()} | Delivery:{" "}
                      {new Date(order.deliveryDate).toLocaleDateString()}
                    </CardDescription>
                  </div>
                  <div className="flex flex-col items-end gap-2">
                    <Badge variant="outline" className={getStatusColor(order.status)}>
                      {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                    </Badge>
                    {daysLeft > 0 && (
                      <Badge variant="secondary" className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {daysLeft} days left
                      </Badge>
                    )}
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Amount</p>
                    <p className="font-semibold">{formatCurrency(order.amount, currency)}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Quantity</p>
                    <p className="font-semibold">{order.quantity} units</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Items</p>
                    <p className="font-semibold">{order.items}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Delivery To</p>
                    <p className="font-semibold">{order.deliveryLocation}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Dialog open={!!selectedOrder} onOpenChange={() => setSelectedOrder(null)}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto" data-testid="dialog-purchase-details">
          {selectedOrder && (
            <>
              <DialogHeader>
                <DialogTitle>Purchase Order Details - {selectedOrder.id}</DialogTitle>
                <DialogDescription>
                  Complete supplier and purchase information
                </DialogDescription>
              </DialogHeader>

              <Tabs defaultValue="supplier" className="w-full">
                <TabsList className="grid w-full grid-cols-4">
                  <TabsTrigger value="supplier">Supplier</TabsTrigger>
                  <TabsTrigger value="details">Details</TabsTrigger>
                  <TabsTrigger value="bank">Payment</TabsTrigger>
                  <TabsTrigger value="delivery">Delivery</TabsTrigger>
                </TabsList>

                {/* Supplier Information Tab */}
                <TabsContent value="supplier" className="space-y-6">
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-lg font-semibold mb-4">Supplier Information</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-3">
                          <div className="flex items-start gap-3">
                            <Building2 className="h-5 w-5 mt-1 text-muted-foreground" />
                            <div>
                              <p className="text-sm text-muted-foreground">Company Name</p>
                              <p className="font-semibold text-base">
                                {selectedOrder.supplier.company}
                              </p>
                            </div>
                          </div>
                          <div className="flex items-start gap-3">
                            <User className="h-5 w-5 mt-1 text-muted-foreground" />
                            <div>
                              <p className="text-sm text-muted-foreground">Contact Person</p>
                              <p className="font-semibold text-base">
                                {selectedOrder.supplier.contactPerson}
                              </p>
                            </div>
                          </div>
                        </div>
                        <div className="space-y-3">
                          <div className="flex items-start gap-3">
                            <Mail className="h-5 w-5 mt-1 text-muted-foreground" />
                            <div>
                              <p className="text-sm text-muted-foreground">Email</p>
                              <p className="font-semibold text-base">
                                {selectedOrder.supplier.email}
                              </p>
                            </div>
                          </div>
                          <div className="flex items-start gap-3">
                            <Phone className="h-5 w-5 mt-1 text-muted-foreground" />
                            <div>
                              <p className="text-sm text-muted-foreground">Phone Number</p>
                              <p className="font-semibold text-base">
                                {selectedOrder.supplier.phone}
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="border-t pt-6">
                      <h3 className="text-lg font-semibold mb-4">Supplier Location</h3>
                      <div className="flex items-start gap-3">
                        <MapPin className="h-5 w-5 mt-1 text-primary" />
                        <div>
                          <p className="font-semibold mb-2">{selectedOrder.location.address}</p>
                          <div className="grid grid-cols-3 gap-4 text-sm">
                            <div>
                              <p className="text-muted-foreground">City</p>
                              <p className="font-medium">{selectedOrder.location.city}</p>
                            </div>
                            <div>
                              <p className="text-muted-foreground">State</p>
                              <p className="font-medium">{selectedOrder.location.state}</p>
                            </div>
                            <div>
                              <p className="text-muted-foreground">Pincode</p>
                              <p className="font-medium">{selectedOrder.location.pincode}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </TabsContent>

                {/* Order Details Tab */}
                <TabsContent value="details" className="space-y-6">
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-lg font-semibold mb-4">Order Specifications</h3>
                      <div className="space-y-4 p-4 bg-muted rounded-lg">
                        <div>
                          <p className="text-sm text-muted-foreground mb-2">Items Required</p>
                          <p className="font-semibold text-base">{selectedOrder.items}</p>
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground mb-2">Quantity</p>
                          <p className="font-semibold text-base">{selectedOrder.quantity} units</p>
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground mb-2">Order Amount</p>
                          <p className="text-2xl font-bold text-primary">
                            {formatCurrency(selectedOrder.amount, currency)}
                          </p>
                        </div>
                      </div>
                    </div>

                    <div>
                      <h3 className="text-lg font-semibold mb-4">Additional Details</h3>
                      <div className="space-y-4 p-4 bg-muted rounded-lg">
                        <div>
                          <p className="text-sm text-muted-foreground mb-2">Payment Terms</p>
                          <p className="font-semibold">{selectedOrder.paymentTerms}</p>
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground mb-2">Specifications</p>
                          <p className="font-semibold">{selectedOrder.specifications}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </TabsContent>

                {/* Bank/Payment Details Tab */}
                <TabsContent value="bank" className="space-y-6">
                  <div>
                    <h3 className="text-lg font-semibold mb-4">Supplier Bank Details</h3>
                    <div className="space-y-4 p-4 bg-muted rounded-lg">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                          <p className="text-sm text-muted-foreground mb-2">Bank Name</p>
                          <p className="font-semibold text-base">
                            {selectedOrder.bank.bankName}
                          </p>
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground mb-2">Account Name</p>
                          <p className="font-semibold text-base">
                            {selectedOrder.bank.accountName}
                          </p>
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground mb-2">Account Number</p>
                          <p className="font-mono font-semibold text-base">
                            {selectedOrder.bank.accountNumber}
                          </p>
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground mb-2">IFSC Code</p>
                          <p className="font-mono font-semibold text-base">
                            {selectedOrder.bank.ifsc}
                          </p>
                        </div>
                      </div>
                    </div>
                    <div className="mt-4 p-4 bg-yellow-50 dark:bg-yellow-950 border border-yellow-200 dark:border-yellow-800 rounded-lg">
                      <p className="text-sm text-yellow-800 dark:text-yellow-100">
                        ⚠️ Bank details are sensitive. Verify before making payments.
                      </p>
                    </div>
                  </div>
                </TabsContent>

                {/* Delivery Details Tab */}
                <TabsContent value="delivery" className="space-y-6">
                  <div>
                    <h3 className="text-lg font-semibold mb-4">Delivery Information</h3>
                    <div className="space-y-4 p-4 bg-muted rounded-lg">
                      <div>
                        <p className="text-sm text-muted-foreground mb-2">Delivery Location</p>
                        <p className="font-semibold text-base">
                          {selectedOrder.deliveryLocation}
                        </p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground mb-2">Expected Delivery Date</p>
                        <p className="font-semibold text-base">
                          {new Date(selectedOrder.deliveryDate).toLocaleDateString("en-US", {
                            weekday: "long",
                            year: "numeric",
                            month: "long",
                            day: "numeric",
                          })}
                        </p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground mb-2">Days Until Delivery</p>
                        <p className="font-semibold text-lg">
                          {getDaysUntilDelivery(selectedOrder.deliveryDate)} days
                        </p>
                      </div>
                    </div>

                    {selectedOrder.status !== "pending" && (
                      <div className="mt-4 p-4 bg-green-50 dark:bg-green-950 border border-green-200 dark:border-green-800 rounded-lg">
                        <p className="text-sm font-semibold text-green-800 dark:text-green-100">
                          ✓ Order Status: {selectedOrder.status.toUpperCase()}
                        </p>
                      </div>
                    )}
                  </div>
                </TabsContent>
              </Tabs>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function getDaysUntilDelivery(deliveryDate: string): number {
  const today = new Date();
  const delivery = new Date(deliveryDate);
  const diffTime = delivery.getTime() - today.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  return diffDays;
}
