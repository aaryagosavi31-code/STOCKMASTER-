import { useQuery } from "@tanstack/react-query";
import { StatCard } from "@/components/stat-card";
import { TransactionHistory, Transaction } from "@/components/transaction-history";
import {
  StockTrendChart,
  CategoryDistributionChart,
  StockStatusChart,
  TopMovingItemsChart,
} from "@/components/analytics-charts";
import { Package, DollarSign, AlertTriangle, TrendingUp } from "lucide-react";
import { isUnauthorizedError } from "@/lib/authUtils";
import { formatDistanceToNow } from "date-fns";
import { formatCurrency } from "@/lib/currency";
import { useLanguage } from "@/components/language-provider";

interface Analytics {
  totalItems: number;
  totalValue: number;
  lowStockCount: number;
  outOfStockCount: number;
}

interface TransactionData {
  id: string;
  type: string;
  itemName: string;
  quantity: number;
  userName: string;
  timestamp: string;
  fromLocation?: string;
  toLocation?: string;
  reference?: string;
}

export default function Dashboard() {
  const { currency, t } = useLanguage();

  const { data: analytics, isLoading: analyticsLoading, error: analyticsError } = useQuery<Analytics>({
    queryKey: ["/api/analytics"],
  });

  const { data: transactionsData = [], isLoading: transactionsLoading, error: transactionsError } = useQuery<TransactionData[]>({
    queryKey: ["/api/transactions"],
  });

  if (analyticsError && isUnauthorizedError(analyticsError)) {
    window.location.href = "/api/login";
  }

  if (transactionsError && isUnauthorizedError(transactionsError)) {
    window.location.href = "/api/login";
  }

  const transactions: Transaction[] = (transactionsData || []).slice(0, 10).map((t: TransactionData) => ({
    id: t.id,
    type: t.type as "in" | "out" | "transfer",
    itemName: t.itemName,
    quantity: t.quantity,
    user: t.userName,
    timestamp: formatDistanceToNow(new Date(t.timestamp), { addSuffix: true }),
    location: t.type === "transfer" 
      ? `${t.fromLocation} → ${t.toLocation}`
      : t.fromLocation || t.toLocation,
    reference: t.reference,
  }));

  if (analyticsLoading || transactionsLoading) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-semibold">{t("dashboard")}</h1>
          <p className="text-muted-foreground">
            {t("dashboardDesc")}
          </p>
        </div>
        <div className="text-center py-8">{t("loadingDashboard")}</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold">{t("dashboard")}</h1>
        <p className="text-muted-foreground">
          {t("dashboardDesc")}
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title={t("totalItems")}
          value={analytics?.totalItems.toLocaleString() || "0"}
          icon={Package}
          subtitle={t("acrossAllWarehouses")}
        />
        <StatCard
          title={t("inventoryValue")}
          value={formatCurrency(analytics?.totalValue || 0, currency, "USD")}
          icon={DollarSign}
        />
        <StatCard
          title={t("lowStockItems")}
          value={analytics?.lowStockCount.toString() || "0"}
          icon={AlertTriangle}
          subtitle={t("requiresAttention")}
        />
        <StatCard
          title={t("outOfStock")}
          value={analytics?.outOfStockCount.toString() || "0"}
          icon={TrendingUp}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <StockTrendChart />
        <CategoryDistributionChart />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <TopMovingItemsChart />
        </div>
        <StockStatusChart />
      </div>

      <TransactionHistory transactions={transactions} />
    </div>
  );
}
