import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Calculator } from "@/components/calculator";
import { AIChatbot } from "@/components/ai-chatbot";
import { useToast } from "@/hooks/use-toast";
import { Users, Share2, LogOut, Plus, Trash2, User, Lock, Bell, Shield, LogIn, Globe, DollarSign as DollarIcon, Check } from "lucide-react";

export default function Settings() {
  const { toast } = useToast();
  const [currency, setCurrency] = useState(() => {
    return localStorage.getItem("currency") || "INR";
  });
  const [language, setLanguage] = useState(() => {
    return localStorage.getItem("language") || "en";
  });
  const [warehouseId, setWarehouseId] = useState(() => {
    return localStorage.getItem("defaultWarehouse") || "";
  });
  const [users, setUsers] = useState<any[]>(() => {
    const stored = localStorage.getItem("users");
    return stored ? JSON.parse(stored) : [
      { id: "1", name: "John Doe", email: "john@stockmaster.com", role: "Admin" },
      { id: "2", name: "Rajesh Kumar", email: "rajesh@stockmaster.com", role: "Manager" },
    ];
  });
  const [newUserEmail, setNewUserEmail] = useState("");
  const [newUserRole, setNewUserRole] = useState("Manager");
  const [sharedWith, setSharedWith] = useState<any[]>(() => {
    const stored = localStorage.getItem("sharedData");
    return stored ? JSON.parse(stored) : [];
  });
  const [showCalculator, setShowCalculator] = useState(false);
  const [showChatbot, setShowChatbot] = useState(false);
  const [accounts, setAccounts] = useState<any[]>([
    { id: "1", name: "John Doe", email: "john@stockmaster.com", active: true },
    { id: "2", name: "Jane Smith", email: "jane@stockmaster.com", active: false },
  ]);
  const [newAccountEmail, setNewAccountEmail] = useState("");
  const [newAccountName, setNewAccountName] = useState("");

  // Language and Currency mappings
  const languageCurrencies = [
    { code: "en", name: "English", currency: "USD", symbol: "$", flag: "🇺🇸" },
    { code: "es", name: "Español (Spanish)", currency: "EUR", symbol: "€", flag: "🇪🇸" },
    { code: "ru", name: "Русский (Russian)", currency: "RUB", symbol: "₽", flag: "🇷🇺" },
    { code: "fr", name: "Français (French)", currency: "EUR", symbol: "€", flag: "🇫🇷" },
    { code: "zh", name: "中文 (Mandarin)", currency: "CNY", symbol: "¥", flag: "🇨🇳" },
    { code: "ja", name: "日本語 (Japanese)", currency: "JPY", symbol: "¥", flag: "🇯🇵" },
    { code: "ko", name: "한국어 (Korean)", currency: "KRW", symbol: "₩", flag: "🇰🇷" },
  ];

  const handleSelectLanguage = (code: string, currencyCode: string) => {
    setLanguage(code);
    setCurrency(currencyCode);
    toast({
      title: "Preferences Updated",
      description: `Language and currency changed successfully`,
    });
  };

  useEffect(() => {
    localStorage.setItem("currency", currency);
  }, [currency]);

  useEffect(() => {
    localStorage.setItem("language", language);
  }, [language]);

  useEffect(() => {
    localStorage.setItem("defaultWarehouse", warehouseId);
  }, [warehouseId]);

  useEffect(() => {
    localStorage.setItem("users", JSON.stringify(users));
  }, [users]);

  useEffect(() => {
    localStorage.setItem("sharedData", JSON.stringify(sharedWith));
  }, [sharedWith]);

  const handleAddUser = () => {
    if (!newUserEmail) {
      toast({
        title: "Error",
        description: "Please enter an email address",
        variant: "destructive",
      });
      return;
    }

    const newUser = {
      id: Date.now().toString(),
      name: newUserEmail.split("@")[0],
      email: newUserEmail,
      role: newUserRole,
    };

    setUsers([...users, newUser]);
    setNewUserEmail("");
    setNewUserRole("Manager");
    toast({
      title: "User Added",
      description: `${newUserEmail} has been added as ${newUserRole}`,
    });
  };

  const handleRemoveUser = (id: string) => {
    setUsers(users.filter((u) => u.id !== id));
    toast({
      title: "User Removed",
      description: "User has been removed from the team",
    });
  };

  const handleShareData = (warehouse: string) => {
    if (sharedWith.find((s) => s.warehouse === warehouse)) {
      toast({
        title: "Already Shared",
        description: "This warehouse data is already shared",
        variant: "destructive",
      });
      return;
    }

    setSharedWith([
      ...sharedWith,
      { warehouse, sharedAt: new Date().toISOString() },
    ]);
    toast({
      title: "Data Shared",
      description: `${warehouse} data shared with all team members`,
    });
  };

  const handleRemoveShare = (warehouse: string) => {
    setSharedWith(sharedWith.filter((s) => s.warehouse !== warehouse));
    toast({
      title: "Share Removed",
      description: "Data sharing has been removed",
    });
  };

  const handleLogout = () => {
    window.location.href = "/api/logout";
  };

  const handleAddAccount = () => {
    if (!newAccountEmail || !newAccountName) {
      toast({
        title: "Error",
        description: "Please enter both name and email",
        variant: "destructive",
      });
      return;
    }

    const newAccount = {
      id: Date.now().toString(),
      name: newAccountName,
      email: newAccountEmail,
      active: false,
    };

    setAccounts([...accounts, newAccount]);
    setNewAccountEmail("");
    setNewAccountName("");
    toast({
      title: "Account Added",
      description: `${newAccountName} has been added`,
    });
  };

  const handleSwitchAccount = (id: string) => {
    setAccounts(
      accounts.map((acc) => ({
        ...acc,
        active: acc.id === id,
      }))
    );
    toast({
      title: "Account Switched",
      description: `Switched to ${accounts.find((a) => a.id === id)?.name}`,
    });
  };

  return (
    <div className="space-y-6 pb-12">
      <div>
        <h1 className="text-2xl font-semibold">Settings</h1>
        <p className="text-muted-foreground">Manage your account, preferences and team access</p>
      </div>

      <Tabs defaultValue="account" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="account" className="flex items-center gap-2">
            <User className="h-4 w-4" />
            <span className="hidden sm:inline">Account</span>
          </TabsTrigger>
          <TabsTrigger value="team" className="flex items-center gap-2">
            <Users className="h-4 w-4" />
            <span className="hidden sm:inline">Team</span>
          </TabsTrigger>
          <TabsTrigger value="sharing" className="flex items-center gap-2">
            <Share2 className="h-4 w-4" />
            <span className="hidden sm:inline">Sharing</span>
          </TabsTrigger>
          <TabsTrigger value="security" className="flex items-center gap-2">
            <Shield className="h-4 w-4" />
            <span className="hidden sm:inline">Security</span>
          </TabsTrigger>
        </TabsList>

        {/* Account Settings (GitHub Style) */}
        <TabsContent value="account" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="h-5 w-5" />
                Account Management
              </CardTitle>
              <CardDescription>Manage your StockMaster accounts</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Current Account */}
              <div className="space-y-3">
                <Label className="text-base font-medium">Current Account</Label>
                <div className="p-4 border rounded-lg bg-blue-50 dark:bg-blue-950">
                  {accounts.find((a) => a.active) && (
                    <div>
                      <p className="font-semibold">{accounts.find((a) => a.active)?.name}</p>
                      <p className="text-sm text-muted-foreground">{accounts.find((a) => a.active)?.email}</p>
                      <Badge className="mt-2" data-testid="badge-current-account">Active</Badge>
                    </div>
                  )}
                </div>
              </div>

              {/* Switch Accounts */}
              <div className="space-y-3">
                <Label className="text-base font-medium">Switch Account</Label>
                <div className="space-y-2">
                  {accounts.filter((a) => !a.active).map((account) => (
                    <div
                      key={account.id}
                      className="flex items-center justify-between p-3 border rounded-lg hover:bg-slate-50 dark:hover:bg-slate-900"
                      data-testid={`account-item-${account.id}`}
                    >
                      <div>
                        <p className="font-medium">{account.name}</p>
                        <p className="text-sm text-muted-foreground">{account.email}</p>
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleSwitchAccount(account.id)}
                        data-testid={`button-switch-account-${account.id}`}
                      >
                        <LogIn className="h-3 w-3 mr-1" />
                        Switch
                      </Button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Add New Account */}
              <div className="space-y-3 border-t pt-6">
                <Label className="text-base font-medium">Add Another Account</Label>
                <div className="space-y-3">
                  <Input
                    placeholder="Full Name"
                    value={newAccountName}
                    onChange={(e) => setNewAccountName(e.target.value)}
                    data-testid="input-new-account-name"
                  />
                  <Input
                    placeholder="Email address"
                    value={newAccountEmail}
                    onChange={(e) => setNewAccountEmail(e.target.value)}
                    data-testid="input-new-account-email"
                  />
                  <Button onClick={handleAddAccount} className="w-full" data-testid="button-add-account">
                    <Plus className="h-4 w-4 mr-2" />
                    Add Account
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Team Management */}
        <TabsContent value="team" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                Team Members
              </CardTitle>
              <CardDescription>Add and manage team members</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-3">
                <Label className="text-base font-medium">Add New User</Label>
                <div className="flex gap-2 flex-wrap">
                  <Input
                    placeholder="Email address"
                    value={newUserEmail}
                    onChange={(e) => setNewUserEmail(e.target.value)}
                    className="flex-1 min-w-[200px]"
                    data-testid="input-user-email"
                  />
                  <Select value={newUserRole} onValueChange={setNewUserRole}>
                    <SelectTrigger className="w-[150px]" data-testid="select-user-role">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Admin">Admin</SelectItem>
                      <SelectItem value="Manager">Manager</SelectItem>
                      <SelectItem value="Viewer">Viewer</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button onClick={handleAddUser} data-testid="button-add-user">
                    <Plus className="h-4 w-4 mr-2" />
                    Add
                  </Button>
                </div>
              </div>

              <div className="space-y-3">
                <Label className="text-base font-medium">Current Users ({users.length})</Label>
                <div className="space-y-2">
                  {users.map((user) => (
                    <div
                      key={user.id}
                      className="flex items-center justify-between p-3 border rounded-md"
                      data-testid={`user-item-${user.id}`}
                    >
                      <div className="flex-1">
                        <p className="font-medium">{user.name}</p>
                        <p className="text-sm text-muted-foreground">{user.email}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">{user.role}</Badge>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleRemoveUser(user.id)}
                          data-testid={`button-remove-user-${user.id}`}
                        >
                          <Trash2 className="h-4 w-4 text-red-600" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Data Sharing */}
        <TabsContent value="sharing" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Share2 className="h-5 w-5" />
                Warehouse Data Sharing
              </CardTitle>
              <CardDescription>Share warehouse and stock data with team members</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-3">
                <Label className="text-base font-medium">Share Warehouse Data</Label>
                <div className="space-y-2">
                  {["Warehouse A - Mumbai", "Warehouse B - Delhi", "Warehouse C - Bangalore"].map((warehouse) => {
                    const isShared = sharedWith.find((s) => s.warehouse === warehouse);
                    return (
                      <div
                        key={warehouse}
                        className="flex items-center justify-between p-3 border rounded-md"
                      >
                        <div>
                          <p className="font-medium">{warehouse}</p>
                          <p className="text-sm text-muted-foreground">
                            {isShared ? "Shared with all team members" : "Not shared"}
                          </p>
                        </div>
                        {isShared ? (
                          <Button
                            variant="outline"
                            onClick={() => handleRemoveShare(warehouse)}
                            data-testid={`button-unshare-${warehouse}`}
                          >
                            Remove Share
                          </Button>
                        ) : (
                          <Button
                            onClick={() => handleShareData(warehouse)}
                            data-testid={`button-share-${warehouse}`}
                          >
                            Share
                          </Button>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="space-y-3">
                <Label className="text-base font-medium">Shared Warehouses ({sharedWith.length})</Label>
                {sharedWith.length === 0 ? (
                  <p className="text-sm text-muted-foreground">No warehouses shared yet</p>
                ) : (
                  <div className="space-y-2">
                    {sharedWith.map((share) => (
                      <div key={share.warehouse} className="p-3 bg-green-50 dark:bg-green-950 border border-green-200 dark:border-green-800 rounded-md">
                        <p className="font-medium text-green-900 dark:text-green-100">{share.warehouse}</p>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Security & Privacy */}
        <TabsContent value="security" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Lock className="h-5 w-5" />
                Security & Privacy
              </CardTitle>
              <CardDescription>Manage security settings and privacy</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <Button variant="outline" className="w-full justify-start" data-testid="button-change-password">
                  <Lock className="h-4 w-4 mr-2" />
                  Change Password
                </Button>
                <Button variant="outline" className="w-full justify-start" data-testid="button-two-factor">
                  <Shield className="h-4 w-4 mr-2" />
                  Enable Two-Factor Authentication
                </Button>
                <Button variant="outline" className="w-full justify-start" data-testid="button-login-history">
                  <LogIn className="h-4 w-4 mr-2" />
                  View Login History
                </Button>
              </div>

              <div className="pt-4 border-t">
                <h3 className="font-semibold mb-3">Active Sessions</h3>
                <div className="space-y-2">
                  <div className="p-3 border rounded-lg flex items-center justify-between">
                    <div>
                      <p className="font-medium text-sm">Current Session</p>
                      <p className="text-xs text-muted-foreground">Chrome on Mac OS</p>
                    </div>
                    <Badge>Active Now</Badge>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tools */}
        <TabsContent value="tools" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Quick Tools</CardTitle>
              <CardDescription>Access useful tools for calculations and decision making</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Button
                onClick={() => setShowCalculator(!showCalculator)}
                variant="outline"
                className="w-full justify-start"
                data-testid="button-toggle-calculator"
              >
                <span>🧮</span>
                <span className="ml-2">Mini Calculator</span>
              </Button>
              <Button
                onClick={() => setShowChatbot(!showChatbot)}
                variant="outline"
                className="w-full justify-start"
                data-testid="button-toggle-chatbot"
              >
                <span>🤖</span>
                <span className="ml-2">AI Assistant</span>
              </Button>
            </CardContent>
          </Card>

          {showCalculator && <Calculator onClose={() => setShowCalculator(false)} />}
          {showChatbot && <AIChatbot onClose={() => setShowChatbot(false)} />}
        </TabsContent>
      </Tabs>

      {/* Logout Button */}
      <div className="flex gap-3">
        <Button
          variant="destructive"
          onClick={handleLogout}
          data-testid="button-logout-settings"
          className="flex items-center gap-2"
        >
          <LogOut className="h-4 w-4" />
          Logout
        </Button>
      </div>
    </div>
  );
}
