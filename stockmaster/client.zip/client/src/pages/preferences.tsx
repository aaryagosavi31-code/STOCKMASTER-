import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Globe, DollarSign as DollarIcon, Check, Warehouse } from "lucide-react";
import { useLanguage } from "@/components/language-provider";

export default function Preferences() {
  const { toast } = useToast();
  const { setLanguageAndCurrency, language, currency, t } = useLanguage();
  const [warehouseId, setWarehouseId] = useState(() => {
    return localStorage.getItem("defaultWarehouse") || "none";
  });

  // Language and Currency mappings
  const languageCurrencies = [
    { code: "en", name: "English", currency: "USD", symbol: "$", flag: "🇺🇸" },
    { code: "en-inr", name: "English (India)", currency: "INR", symbol: "₹", flag: "🇮🇳" },
    { code: "es", name: "Español (Spanish)", currency: "EUR", symbol: "€", flag: "🇪🇸" },
    { code: "ru", name: "Русский (Russian)", currency: "RUB", symbol: "₽", flag: "🇷🇺" },
    { code: "fr", name: "Français (French)", currency: "EUR", symbol: "€", flag: "🇫🇷" },
    { code: "zh", name: "中文 (Mandarin)", currency: "CNY", symbol: "¥", flag: "🇨🇳" },
    { code: "ja", name: "日本語 (Japanese)", currency: "JPY", symbol: "¥", flag: "🇯🇵" },
    { code: "ko", name: "한국어 (Korean)", currency: "KRW", symbol: "₩", flag: "🇰🇷" },
  ];

  const handleSelectLanguage = (code: string, currencyCode: string) => {
    setLanguageAndCurrency(code, currencyCode);
    localStorage.setItem("defaultWarehouse", warehouseId);
    toast({
      title: t("preferences"),
      description: "Language and currency changed successfully",
    });
  };

  return (
    <div className="space-y-6 pb-12">
      <div>
        <h1 className="text-2xl font-semibold">{t("preferences")}</h1>
        <p className="text-muted-foreground">{t("preferencesDesc")}</p>
      </div>

      {/* Display & Localization */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Globe className="h-5 w-5" />
            {t("language")} & {t("currency")}
          </CardTitle>
          <CardDescription>{t("chooseLanguageAndCurrency")}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Current Selection */}
          <div className="space-y-3">
            <Label className="text-base font-medium">{t("currentSelection")}</Label>
            <div className="p-4 border rounded-lg bg-blue-50 dark:bg-blue-950">
              {languageCurrencies.find((lc) => lc.code === language) && (
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-semibold">
                      {languageCurrencies.find((lc) => lc.code === language)?.flag}{" "}
                      {languageCurrencies.find((lc) => lc.code === language)?.name}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      {t("currency")}: {languageCurrencies.find((lc) => lc.code === language)?.currency} ({languageCurrencies.find((lc) => lc.code === language)?.symbol})
                    </p>
                  </div>
                  <Badge data-testid="badge-current-language">{t("active")}</Badge>
                </div>
              )}
            </div>
          </div>

          {/* Language Cards Grid */}
          <div className="space-y-3">
            <Label className="text-base font-medium">{t("selectLanguageCurrency")}</Label>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {languageCurrencies.map((lc) => (
                <div
                  key={lc.code}
                  onClick={() => handleSelectLanguage(lc.code, lc.currency)}
                  className={`p-4 border rounded-lg cursor-pointer transition-all hover:shadow-md ${
                    language === lc.code
                      ? "border-primary bg-primary/5 dark:bg-primary/10"
                      : "border-border hover:border-primary/50"
                  }`}
                  data-testid={`language-card-${lc.code}`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <p className="text-lg font-semibold flex items-center gap-2">
                        <span className="text-2xl">{lc.flag}</span>
                        {lc.name}
                      </p>
                      <p className="text-sm text-muted-foreground mt-2">
                        {lc.currency} {lc.symbol}
                      </p>
                    </div>
                    {language === lc.code && (
                      <div className="flex-shrink-0">
                        <Check className="h-5 w-5 text-primary" />
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Warehouse Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Warehouse className="h-5 w-5" />
            {t("warehouseSettings")}
          </CardTitle>
          <CardDescription>{t("configureWarehouses")}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <Label htmlFor="warehouse" className="text-base font-medium">
            {t("defaultWarehouse")}
          </Label>
          <Select value={warehouseId} onValueChange={setWarehouseId}>
            <SelectTrigger id="warehouse" className="w-full" data-testid="select-warehouse">
              <SelectValue placeholder={t("search")} />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="none">{t("noDefaultWarehouse")}</SelectItem>
              <SelectItem value="warehouse-1">Warehouse A - Mumbai</SelectItem>
              <SelectItem value="warehouse-2">Warehouse B - Delhi</SelectItem>
              <SelectItem value="warehouse-3">Warehouse C - Bangalore</SelectItem>
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      {/* System Information */}
      <Card>
        <CardHeader>
          <CardTitle>{t("systemInformation")}</CardTitle>
          <CardDescription>Application details and version</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-sm font-medium text-muted-foreground">Application</p>
              <p className="text-base font-semibold">StockMaster IMS</p>
            </div>
            <div>
              <p className="text-sm font-medium text-muted-foreground">{t("version")}</p>
              <p className="text-base font-semibold">3.0.0</p>
            </div>
            <div>
              <p className="text-sm font-medium text-muted-foreground">{t("environment")}</p>
              <p className="text-base font-semibold">Production</p>
            </div>
            <div>
              <p className="text-sm font-medium text-muted-foreground">{t("database")}</p>
              <p className="text-base font-semibold">PostgreSQL</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
