import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  User, 
  Phone, 
  Mail, 
  MapPin, 
  Banknote, 
  Calendar, 
  Package,
  Plus,
  Eye
} from "lucide-react";
import { formatCurrency } from "@/lib/currency";
import { CreateTransactionOrderDialog } from "@/components/create-transaction-order";

const transactions = [
  {
    id: "TXN001",
    date: "2024-11-22",
    status: "completed",
    amount: 45000,
    quantity: 50,
    items: "Electronics",
    buyer: {
      name: "Amit Electronics",
      email: "amit@electronics.com",
      phone: "+91-98765-43210",
      company: "Amit Electronics Ltd.",
    },
    bank: {
      accountName: "Amit Electronics Ltd.",
      accountNumber: "1234567890123456",
      ifsc: "HDFC0001234",
      bankName: "HDFC Bank",
    },
    destination: {
      address: "123 Retail Street",
      city: "Mumbai",
      state: "Maharashtra",
      pincode: "400001",
      coordinates: "19.0760, 72.8777",
    },
  },
  {
    id: "TXN002",
    date: "2024-11-21",
    status: "in-transit",
    amount: 32500,
    quantity: 75,
    items: "Furniture",
    buyer: {
      name: "Delhi Furniture Mart",
      email: "sales@delhifurniture.com",
      phone: "+91-98123-45678",
      company: "Delhi Furniture Mart Pvt Ltd.",
    },
    bank: {
      accountName: "Delhi Furniture Mart Pvt Ltd.",
      accountNumber: "9876543210987654",
      ifsc: "ICIC0000456",
      bankName: "ICICI Bank",
    },
    destination: {
      address: "456 Commercial Plaza",
      city: "Delhi",
      state: "NCR",
      pincode: "110015",
      coordinates: "28.6139, 77.2090",
    },
  },
  {
    id: "TXN003",
    date: "2024-11-20",
    status: "pending",
    amount: 58000,
    quantity: 120,
    items: "Appliances",
    buyer: {
      name: "Bangalore Tech Store",
      email: "orders@bangaloretech.com",
      phone: "+91-98456-78901",
      company: "Bangalore Tech Store Inc.",
    },
    bank: {
      accountName: "Bangalore Tech Store Inc.",
      accountNumber: "5555666677778888",
      ifsc: "AXIS0000789",
      bankName: "Axis Bank",
    },
    destination: {
      address: "789 Tech Avenue",
      city: "Bangalore",
      state: "Karnataka",
      pincode: "560034",
      coordinates: "12.9716, 77.5946",
    },
  },
];

interface Transaction {
  id: string;
  date: string;
  status: string;
  amount: number;
  quantity: number;
  items: string;
  buyer: {
    name: string;
    email: string;
    phone: string;
    company: string;
  };
  bank: {
    accountName: string;
    accountNumber: string;
    ifsc: string;
    bankName: string;
  };
  destination: {
    address: string;
    city: string;
    state: string;
    pincode: string;
    coordinates: string;
  };
}

export default function Transactions() {
  const [currency] = useState(() => localStorage.getItem("currency") || "INR");
  const [selectedTransaction, setSelectedTransaction] = useState<Transaction | null>(null);
  const [statusFilter, setStatusFilter] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");
  const [isCreateOrderDialogOpen, setIsCreateOrderDialogOpen] = useState(false);
  const [transactionOrders, setTransactionOrders] = useState<any[]>([]);

  const handleOrderCreated = (newOrder: any) => {
    setTransactionOrders([...transactionOrders, newOrder]);
  };

  const filteredTransactions = transactions.filter((t) => {
    const matchesStatus = statusFilter === "all" || t.status === statusFilter;
    const matchesSearch =
      t.buyer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      t.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      t.buyer.email.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  const totalAmount = transactions.reduce((sum, t) => sum + t.amount, 0);
  const completedCount = transactions.filter((t) => t.status === "completed").length;
  const pendingCount = transactions.filter((t) => t.status === "pending").length;

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-green-50 text-green-700 border-green-200 dark:bg-green-950 dark:text-green-50 dark:border-green-800";
      case "in-transit":
        return "bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-950 dark:text-blue-50 dark:border-blue-800";
      case "pending":
        return "bg-yellow-50 text-yellow-700 border-yellow-200 dark:bg-yellow-950 dark:text-yellow-50 dark:border-yellow-800";
      default:
        return "bg-gray-50 text-gray-700 border-gray-200 dark:bg-gray-950 dark:text-gray-50 dark:border-gray-800";
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold">Transactions</h1>
        <p className="text-muted-foreground">
          View and manage all buyer transactions with delivery details
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Transactions</p>
                <p className="text-2xl font-bold">{transactions.length}</p>
              </div>
              <Package className="h-8 w-8 text-primary opacity-70" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Revenue</p>
                <p className="text-2xl font-bold">{formatCurrency(totalAmount, currency)}</p>
              </div>
              <Banknote className="h-8 w-8 text-primary opacity-70" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Completed</p>
                <p className="text-2xl font-bold text-green-600">{completedCount}</p>
              </div>
              <div className="text-sm text-muted-foreground">Delivered</div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Pending</p>
                <p className="text-2xl font-bold text-yellow-600">{pendingCount}</p>
              </div>
              <div className="text-sm text-muted-foreground">In Progress</div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Filters</CardTitle>
            </div>
            <Button
              onClick={() => setIsCreateOrderDialogOpen(true)}
              className="gap-2"
              data-testid="button-add-transaction-order"
            >
              <Plus className="h-4 w-4" />
              Add Order
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-4 flex-wrap">
            <div className="flex-1 min-w-[200px]">
              <Label htmlFor="search" className="text-sm mb-2 block">
                Search by Buyer or ID
              </Label>
              <Input
                id="search"
                placeholder="Search buyer name, email, or transaction ID..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                data-testid="input-search-transactions"
              />
            </div>
            <div className="w-[200px]">
              <Label htmlFor="status" className="text-sm mb-2 block">
                Status
              </Label>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger id="status" data-testid="select-transaction-status">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Transactions</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="in-transit">In Transit</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="space-y-4">
        {filteredTransactions.map((transaction) => (
          <Card key={transaction.id} className="hover-elevate cursor-pointer" onClick={() => setSelectedTransaction(transaction)}>
            <CardContent className="pt-6">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-3">
                    <h3 className="font-semibold">{transaction.id}</h3>
                    <Badge className={getStatusColor(transaction.status)}>
                      {transaction.status.charAt(0).toUpperCase() + transaction.status.slice(1)}
                    </Badge>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <div className="flex items-center gap-2 text-sm">
                      <User className="h-4 w-4 text-muted-foreground" />
                      <span>{transaction.buyer.name}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <Calendar className="h-4 w-4 text-muted-foreground" />
                      <span>{transaction.date}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <Mail className="h-4 w-4 text-muted-foreground" />
                      <span>{transaction.buyer.email}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <Banknote className="h-4 w-4 text-muted-foreground" />
                      <span className="font-semibold">{formatCurrency(transaction.amount, currency)}</span>
                    </div>
                  </div>
                  <div className="text-sm text-muted-foreground">
                    <p>{transaction.items} • {transaction.quantity} units</p>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={(e) => {
                    e.stopPropagation();
                    setSelectedTransaction(transaction);
                  }}
                  data-testid={`button-view-transaction-${transaction.id}`}
                >
                  <Eye className="h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {selectedTransaction && (
        <Dialog open={!!selectedTransaction} onOpenChange={() => setSelectedTransaction(null)}>
          <DialogContent className="max-h-[90vh] overflow-y-auto max-w-2xl">
            <DialogHeader>
              <DialogTitle>Transaction Details - {selectedTransaction.id}</DialogTitle>
              <DialogDescription>Complete transaction and delivery information</DialogDescription>
            </DialogHeader>

            <Tabs defaultValue="buyer" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="buyer">Buyer Info</TabsTrigger>
                <TabsTrigger value="delivery">Delivery</TabsTrigger>
                <TabsTrigger value="bank">Bank Details</TabsTrigger>
              </TabsList>

              <TabsContent value="buyer" className="space-y-4 mt-4">
                <div>
                  <Label className="text-xs text-muted-foreground">Buyer Name</Label>
                  <p className="font-semibold">{selectedTransaction.buyer.name}</p>
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">Company</Label>
                  <p className="font-semibold">{selectedTransaction.buyer.company}</p>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-xs text-muted-foreground flex items-center gap-2">
                      <Mail className="h-3 w-3" /> Email
                    </Label>
                    <p className="text-sm">{selectedTransaction.buyer.email}</p>
                  </div>
                  <div>
                    <Label className="text-xs text-muted-foreground flex items-center gap-2">
                      <Phone className="h-3 w-3" /> Phone
                    </Label>
                    <p className="text-sm">{selectedTransaction.buyer.phone}</p>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="delivery" className="space-y-4 mt-4">
                <div>
                  <Label className="text-xs text-muted-foreground">Delivery Address</Label>
                  <p className="font-semibold">{selectedTransaction.destination.address}</p>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-xs text-muted-foreground">City</Label>
                    <p className="text-sm">{selectedTransaction.destination.city}</p>
                  </div>
                  <div>
                    <Label className="text-xs text-muted-foreground">State</Label>
                    <p className="text-sm">{selectedTransaction.destination.state}</p>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-xs text-muted-foreground">Pincode</Label>
                    <p className="text-sm">{selectedTransaction.destination.pincode}</p>
                  </div>
                  <div>
                    <Label className="text-xs text-muted-foreground">Coordinates</Label>
                    <p className="text-sm">{selectedTransaction.destination.coordinates}</p>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="bank" className="space-y-4 mt-4">
                <div>
                  <Label className="text-xs text-muted-foreground">Bank Name</Label>
                  <p className="font-semibold">{selectedTransaction.bank.bankName}</p>
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">Account Name</Label>
                  <p className="font-semibold">{selectedTransaction.bank.accountName}</p>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-xs text-muted-foreground">Account Number</Label>
                    <p className="text-sm font-mono">{selectedTransaction.bank.accountNumber}</p>
                  </div>
                  <div>
                    <Label className="text-xs text-muted-foreground">IFSC Code</Label>
                    <p className="text-sm font-mono">{selectedTransaction.bank.ifsc}</p>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </DialogContent>
        </Dialog>
      )}

      <CreateTransactionOrderDialog
        open={isCreateOrderDialogOpen}
        onOpenChange={setIsCreateOrderDialogOpen}
        onOrderCreated={handleOrderCreated}
      />
    </div>
  );
}
