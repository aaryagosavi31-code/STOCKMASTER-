import { Footer } from "@/components/footer";
import { Github, Linkedin, Mail } from "lucide-react";

export default function About() {
  const team = [
    {
      name: "Janhvi Shintre",
      role: "Full Stack Developer & Lead Designer",
      description: "Specialized in building scalable inventory management systems with modern web technologies.",
      email: "janhvi@stockmaster.com",
      linkedin: "https://linkedin.com/in/janhvi-shintre",
      github: "https://github.com/janhvi-shintre",
    },
    {
      name: "Aarya Gosavi",
      role: "Backend Engineer & Database Specialist",
      description: "Expert in designing efficient database schemas and building robust backend APIs.",
      email: "aarya@stockmaster.com",
      linkedin: "https://linkedin.com/in/aarya-gosavi",
      github: "https://github.com/aarya-gosavi",
    },
    {
      name: "Riya Duddalwar",
      role: "UI/UX Designer & Frontend Developer",
      description: "Passionate about creating intuitive user interfaces and seamless user experiences.",
      email: "riya@stockmaster.com",
      linkedin: "https://linkedin.com/in/riya-duddalwar",
      github: "https://github.com/riya-duddalwar",
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-6xl mx-auto px-6 py-16">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold mb-4">About StockMaster</h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            A modern, enterprise-grade inventory management system built to streamline stock operations and drive business growth.
          </p>
        </div>

        {/* Mission */}
        <section className="mb-16">
          <div className="bg-slate-50 dark:bg-slate-900 rounded-xl p-8 mb-8">
            <h2 className="text-2xl font-bold mb-4">Our Mission</h2>
            <p className="text-muted-foreground leading-relaxed mb-4">
              StockFlow was created with a singular vision: to empower businesses of all sizes with intelligent inventory management tools. We believe that effective stock management is the backbone of operational excellence, and our platform is designed to make it simple, transparent, and data-driven.
            </p>
            <p className="text-muted-foreground leading-relaxed">
              By combining cutting-edge technology with an intuitive interface, we help businesses reduce waste, optimize warehouse operations, and make informed decisions that directly impact their bottom line.
            </p>
          </div>
        </section>

        {/* Features */}
        <section className="mb-16">
          <h2 className="text-2xl font-bold mb-8">What Makes StockFlow Special</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-slate-50 dark:bg-slate-900 rounded-xl p-6">
              <h3 className="text-lg font-semibold mb-3">Real-Time Analytics</h3>
              <p className="text-muted-foreground text-sm">
                Get instant insights into your inventory with live dashboards, trend analysis, and predictive forecasting.
              </p>
            </div>
            <div className="bg-slate-50 dark:bg-slate-900 rounded-xl p-6">
              <h3 className="text-lg font-semibold mb-3">Multi-Warehouse Support</h3>
              <p className="text-muted-foreground text-sm">
                Manage inventory across multiple locations with centralized control and seamless synchronization.
              </p>
            </div>
            <div className="bg-slate-50 dark:bg-slate-900 rounded-xl p-6">
              <h3 className="text-lg font-semibold mb-3">AI-Powered Insights</h3>
              <p className="text-muted-foreground text-sm">
                Leverage our AI management advisor for intelligent recommendations and optimization strategies.
              </p>
            </div>
          </div>
        </section>

        {/* Team */}
        <section>
          <h2 className="text-2xl font-bold mb-8 text-center">Meet the Team</h2>
          <p className="text-center text-muted-foreground mb-12 max-w-2xl mx-auto">
            StockFlow is built by three passionate developers dedicated to creating the best inventory management experience.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {team.map((member) => (
              <div key={member.name} className="bg-slate-50 dark:bg-slate-900 rounded-xl p-8 text-center">
                <div className="mb-4">
                  <div className="w-20 h-20 rounded-full bg-gradient-to-br from-blue-400 to-purple-600 mx-auto flex items-center justify-center">
                    <span className="text-white text-2xl font-bold">
                      {member.name.split(" ").map((n) => n[0]).join("")}
                    </span>
                  </div>
                </div>
                <h3 className="text-lg font-semibold mb-2">{member.name}</h3>
                <p className="text-primary font-medium text-sm mb-3">{member.role}</p>
                <p className="text-muted-foreground text-sm mb-6 leading-relaxed">
                  {member.description}
                </p>
                <div className="flex justify-center gap-3">
                  <a
                    href={`mailto:${member.email}`}
                    className="p-2 rounded-lg bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white transition-colors"
                    data-testid={`link-email-${member.name.split(" ")[0].toLowerCase()}`}
                  >
                    <Mail className="h-4 w-4" />
                  </a>
                  <a
                    href={member.linkedin}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2 rounded-lg bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white transition-colors"
                    data-testid={`link-linkedin-${member.name.split(" ")[0].toLowerCase()}`}
                  >
                    <Linkedin className="h-4 w-4" />
                  </a>
                  <a
                    href={member.github}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2 rounded-lg bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white transition-colors"
                    data-testid={`link-github-${member.name.split(" ")[0].toLowerCase()}`}
                  >
                    <Github className="h-4 w-4" />
                  </a>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Trademark */}
        <section className="mt-16 bg-blue-50 dark:bg-blue-950 rounded-xl p-8">
          <h2 className="text-2xl font-bold mb-4">Trademark & Credits</h2>
          <div className="space-y-4 text-muted-foreground">
            <p>
              <strong>StockFlow™</strong> is a trademark of StockFlow Solutions. All rights reserved.
            </p>
            <p>
              Built with excellence by <strong>Janhvi Shintre</strong>, <strong>Aarya Gosavi</strong>, and <strong>Riya Duddalwar</strong>.
            </p>
            <p>
              © 2025 StockFlow. All rights reserved. Designed and developed in India.
            </p>
            <p className="pt-4 border-t border-blue-200 dark:border-blue-800">
              StockFlow combines modern web technologies including React, Node.js, PostgreSQL, and AI-powered insights to deliver an exceptional inventory management platform.
            </p>
          </div>
        </section>
      </div>
      <Footer />
    </div>
  );
}
