import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { LandingNavbar } from "@/components/landing-navbar";
import { Check, Zap } from "lucide-react";

export default function Pricing() {
  const [, navigate] = useLocation();

  const plans = [
    {
      name: "Basic",
      monthlyPrice: 24,
      yearlyPrice: 288,
      savings: "You'll save $300!",
      description: "Perfect for small businesses",
      features: [
        { name: "Unique items", value: "500", max: 500 },
        { name: "User licenses", value: "2", max: 2 },
        { name: "QR labels", included: true },
        { name: "Mobile app", included: true },
        { name: "Basic reports", included: true },
      ],
      cta: "Start Free Trial",
      secondary: "Buy Now",
      highlighted: false,
    },
    {
      name: "Ultra",
      monthlyPrice: 74,
      yearlyPrice: 888,
      savings: "You'll save $900!",
      description: "For growing teams",
      features: [
        { name: "Unique items", value: "2000", max: 2000 },
        { name: "User licenses", value: "5", max: 5 },
        { name: "Unlimited QR labels", included: true },
        { name: "QuickBooks integration", included: true },
        { name: "Role permissions", included: true },
        { name: "Advanced analytics", included: true },
      ],
      cta: "Start Free Trial",
      secondary: "Buy Now",
      highlighted: true,
    },
    {
      name: "Premium",
      monthlyPrice: 149,
      yearlyPrice: 1788,
      savings: "You'll save $1,800!",
      description: "For enterprise teams",
      features: [
        { name: "Unique items", value: "5000", max: 5000 },
        { name: "User licenses", value: "8", max: 8 },
        { name: "Unlimited QR labels", included: true },
        { name: "QuickBooks integration", included: true },
        { name: "Role permissions", included: true },
        { name: "Purchase orders", included: true },
        { name: "Custom integrations", included: true },
        { name: "Dedicated support", included: true },
      ],
      cta: "Start Free Trial",
      secondary: "Talk to Sales",
      highlighted: false,
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <LandingNavbar />

      {/* Flash Sale Banner */}
      <div className="bg-gradient-to-r from-red-500 to-red-600 text-white py-4 sticky top-16 z-40">
        <div className="max-w-7xl mx-auto px-6 text-center flex items-center justify-center gap-2">
          <Zap className="h-5 w-5" />
          <span className="font-semibold">Flash Sale: 50% off yearly plans!</span>
        </div>
      </div>

      {/* Pricing Section */}
      <section className="py-20 lg:py-32 bg-background">
        <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12">
          {/* Header */}
          <div className="text-center mb-16">
            <h1 className="text-4xl lg:text-5xl font-bold mb-4">Simple, Transparent Pricing</h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Choose the perfect plan for your inventory management needs
            </p>
          </div>

          {/* Pricing Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {plans.map((plan, idx) => (
              <div key={idx} className="relative">
                {/* Most Popular Ribbon */}
                {plan.highlighted && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 z-10">
                    <div className="bg-blue-600 text-white px-4 py-1 rounded-full text-sm font-semibold">
                      Most Popular
                    </div>
                  </div>
                )}

                {/* Card */}
                <div
                  className={`rounded-2xl overflow-hidden transition-all ${
                    plan.highlighted
                      ? "ring-2 ring-blue-600 shadow-xl md:scale-105"
                      : "border border-border hover:shadow-lg"
                  } bg-white dark:bg-card`}
                >
                  <div className="p-8">
                    {/* Plan Name & Description */}
                    <h3 className="text-2xl font-bold mb-2">{plan.name}</h3>
                    <p className="text-sm text-muted-foreground mb-6">{plan.description}</p>

                    {/* Pricing */}
                    <div className="mb-2">
                      <div className="text-4xl font-bold text-blue-600">
                        ${plan.monthlyPrice}
                        <span className="text-lg text-muted-foreground font-normal">/mo</span>
                      </div>
                    </div>

                    {/* Yearly Billing Note */}
                    <div className="text-sm text-muted-foreground mb-4">
                      Billed at ${plan.yearlyPrice}/yr
                    </div>

                    {/* Savings Badge */}
                    <div className="mb-6 p-3 bg-green-50 dark:bg-green-950 rounded-lg border border-green-200 dark:border-green-800">
                      <p className="text-sm font-semibold text-green-700 dark:text-green-400">
                        {plan.savings}
                      </p>
                    </div>

                    {/* Buttons */}
                    <div className="space-y-3 mb-8">
                      <Button
                        onClick={() => navigate("/signup")}
                        className="w-full bg-blue-600 hover:bg-blue-700 text-white rounded-lg py-2 font-semibold"
                        data-testid={`button-start-trial-${plan.name.toLowerCase()}`}
                      >
                        {plan.cta}
                      </Button>
                      <Button
                        variant="outline"
                        className="w-full rounded-lg py-2 font-semibold"
                        data-testid={`button-secondary-${plan.name.toLowerCase()}`}
                      >
                        {plan.secondary}
                      </Button>
                    </div>

                    {/* Features List */}
                    <div className="space-y-4 pt-8 border-t border-border">
                      {plan.features.map((feature, fidx) => (
                        <div key={fidx}>
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-3">
                              {feature.included ? (
                                <Check className="h-5 w-5 text-green-600" />
                              ) : (
                                <div className="h-5 w-5 rounded bg-muted"></div>
                              )}
                              <span className="text-sm font-medium">{feature.name}</span>
                            </div>
                            {feature.value && <span className="text-sm font-bold text-blue-600">{feature.value}</span>}
                          </div>

                          {/* Progress Bar for Numeric Values */}
                          {feature.max && (
                            <div className="ml-8 h-2 bg-muted rounded-full overflow-hidden">
                              <div
                                className="h-full bg-blue-600 transition-all"
                                style={{ width: `${(parseInt(feature.value || "0") / feature.max) * 100}%` }}
                              ></div>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* FAQ Section */}
          <div className="mt-20 max-w-3xl mx-auto">
            <h2 className="text-2xl font-bold text-center mb-8">Frequently Asked Questions</h2>
            <div className="space-y-4">
              {[
                {
                  q: "Can I change plans anytime?",
                  a: "Yes, you can upgrade or downgrade your plan at any time. Changes take effect at the next billing cycle.",
                },
                {
                  q: "What payment methods do you accept?",
                  a: "We accept all major credit cards, PayPal, and bank transfers for enterprise customers.",
                },
                {
                  q: "Is there a free trial?",
                  a: "Yes, all plans come with a 14-day free trial. No credit card required to get started.",
                },
                {
                  q: "What about data security?",
                  a: "We use enterprise-grade encryption and comply with GDPR, SOC 2, and ISO 27001 standards.",
                },
              ].map((faq, idx) => (
                <div key={idx} className="p-4 rounded-lg border border-border bg-card">
                  <h4 className="font-semibold mb-2">{faq.q}</h4>
                  <p className="text-sm text-muted-foreground">{faq.a}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-foreground text-background py-12 border-t border-background/20">
        <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12">
          <div className="flex justify-between items-center flex-wrap gap-4 mb-4">
            <p className="text-sm text-background/80">
              &copy; 2025 StockMaster. All rights reserved.
            </p>
            <div className="flex gap-4">
              {[
                { name: "Github", icon: "github" },
                { name: "Twitter", icon: "twitter" },
                { name: "LinkedIn", icon: "linkedin" },
                { name: "Facebook", icon: "facebook" },
              ].map((social, idx) => (
                <a
                  key={idx}
                  href="#"
                  className="text-background/80 hover:text-background transition-colors"
                >
                  <span className="sr-only">{social.name}</span>
                  <div className="h-5 w-5 bg-background/20 rounded" />
                </a>
              ))}
            </div>
          </div>
          <p className="text-xs text-background/60">
            Made by Aarya Gosavi, Janhvi Shintre and Riya Duddalwar
          </p>
        </div>
      </footer>
    </div>
  );
}
