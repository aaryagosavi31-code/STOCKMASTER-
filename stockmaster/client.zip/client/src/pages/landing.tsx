import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { LandingNavbar } from "@/components/landing-navbar";
import {
  Package,
  Warehouse,
  Zap,
  Bell,
  Barcode,
  TrendingUp,
  Github,
  Twitter,
  Linkedin,
  Facebook,
} from "lucide-react";
import dashboardLightImage from "@assets/generated_images/light_theme_inventory_dashboard_mockup.png";
import dashboardDarkImage from "@assets/generated_images/dark_theme_inventory_dashboard_mockup.png";
import mobileAppImage from "@assets/generated_images/mobile_dashboard_app_mockup.png";

export default function Landing() {
  const [, navigate] = useLocation();

  return (
    <div className="min-h-screen bg-background">
      <LandingNavbar />

      {/* Hero Section - Blue Background */}
      <section className="relative overflow-hidden bg-gradient-to-br from-blue-500 via-blue-600 to-blue-700 py-20 lg:py-32">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-20 left-10 w-72 h-72 bg-white rounded-full mix-blend-multiply filter blur-3xl"></div>
          <div className="absolute top-40 right-10 w-72 h-72 bg-blue-300 rounded-full mix-blend-multiply filter blur-3xl"></div>
        </div>

        <div className="relative max-w-7xl mx-auto px-6 sm:px-8 lg:px-12">
          <div className="text-center mb-12">
            <h1 className="text-5xl lg:text-6xl font-bold text-white mb-6">
              Manage Your Inventory with Confidence
            </h1>
            <p className="text-xl lg:text-2xl text-blue-100 mb-8 max-w-3xl mx-auto">
              Multi-warehouse stock control, real-time tracking, and automated alerts. Everything you need to streamline inventory operations.
            </p>

            <div className="flex gap-4 justify-center flex-wrap">
              <Button
                size="lg"
                onClick={() => navigate("/signup")}
                className="bg-gray-900 hover:bg-black text-white rounded-lg px-8 text-lg"
                data-testid="button-hero-signup"
              >
                Sign Up for Free
              </Button>
              <Button
                size="lg"
                variant="outline"
                onClick={() => navigate("/pricing")}
                className="border-2 border-white text-white hover:bg-white/10 rounded-lg px-8 text-lg"
                data-testid="button-see-all-plans"
              >
                See All Plans
              </Button>
            </div>
          </div>

          {/* Dashboard Preview Image */}
          <div className="mt-12 relative">
            <div className="rounded-2xl overflow-hidden shadow-2xl border-4 border-white/20">
              <img
                src={dashboardLightImage}
                alt="StockMaster Dashboard"
                className="w-full h-auto"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Statistics Section */}
      <section className="w-full bg-gradient-to-r from-blue-50 to-blue-100 dark:from-blue-950 dark:to-blue-900 py-16 lg:py-20">
        <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12">
          <div className="grid grid-cols-1 md:grid-cols-5 gap-8 md:gap-6">
            {[
              { number: "9,000+", label: "Warehouses Managed" },
              { number: "1,500+", label: "Stores Managed" },
              { number: "280+", label: "Integrations" },
              { number: "100 Cr+", label: "Annual Transaction Run-Rate" },
              { number: "7,000+", label: "Clients" },
            ].map((stat, idx) => (
              <div key={idx} className="text-center">
                <div className="text-3xl md:text-4xl font-bold text-blue-600 dark:text-blue-400 mb-2">
                  {stat.number}
                </div>
                <p className="text-xs md:text-sm font-semibold text-gray-800 dark:text-gray-300 uppercase tracking-wide">
                  {stat.label}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Dashboard Showcase Section */}
      <section className="py-20 lg:py-32 bg-background">
        <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12">
          <div className="text-center mb-16">
            <h2 className="text-4xl lg:text-5xl font-bold mb-4">Dashboard Showcase</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Beautiful, intuitive dashboard available in both light and dark modes
            </p>
          </div>

          {/* Light Dashboard */}
          <div className="mb-16">
            <h3 className="text-2xl font-bold mb-6">Light Mode Dashboard</h3>
            <div className="rounded-2xl overflow-hidden shadow-xl border border-border">
              <img
                src={dashboardLightImage}
                alt="Light Dashboard"
                className="w-full h-auto"
              />
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-8">
              <div className="p-4 rounded-lg bg-card border border-border">
                <div className="text-sm text-muted-foreground mb-2">Sales Activity</div>
                <div className="text-2xl font-bold">228</div>
                <div className="text-xs text-muted-foreground mt-1">To be packed</div>
              </div>
              <div className="p-4 rounded-lg bg-card border border-border">
                <div className="text-sm text-muted-foreground mb-2">Shipments</div>
                <div className="text-2xl font-bold">6</div>
                <div className="text-xs text-muted-foreground mt-1">To be shipped</div>
              </div>
              <div className="p-4 rounded-lg bg-card border border-border">
                <div className="text-sm text-muted-foreground mb-2">Deliveries</div>
                <div className="text-2xl font-bold">10</div>
                <div className="text-xs text-muted-foreground mt-1">To be delivered</div>
              </div>
              <div className="p-4 rounded-lg bg-card border border-border">
                <div className="text-sm text-muted-foreground mb-2">Invoicing</div>
                <div className="text-2xl font-bold">474</div>
                <div className="text-xs text-muted-foreground mt-1">To be invoiced</div>
              </div>
            </div>
          </div>

          {/* Dark Dashboard */}
          <div>
            <h3 className="text-2xl font-bold mb-6">Dark Mode Dashboard</h3>
            <div className="rounded-2xl overflow-hidden shadow-xl border border-border">
              <img
                src={dashboardDarkImage}
                alt="Dark Dashboard"
                className="w-full h-auto"
              />
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-8">
              <div className="p-4 rounded-lg bg-[#111] border border-blue-900/30">
                <div className="text-sm text-gray-400 mb-2">Total Items</div>
                <div className="text-2xl font-bold text-white">1,247</div>
                <div className="text-xs text-gray-500 mt-1">In inventory</div>
              </div>
              <div className="p-4 rounded-lg bg-[#111] border border-blue-900/30">
                <div className="text-sm text-gray-400 mb-2">Inventory Value</div>
                <div className="text-2xl font-bold text-blue-400">$487K</div>
                <div className="text-xs text-gray-500 mt-1">Total value</div>
              </div>
              <div className="p-4 rounded-lg bg-[#111] border border-blue-900/30">
                <div className="text-sm text-gray-400 mb-2">Low Stock</div>
                <div className="text-2xl font-bold text-yellow-400">23</div>
                <div className="text-xs text-gray-500 mt-1">Items below threshold</div>
              </div>
              <div className="p-4 rounded-lg bg-[#111] border border-blue-900/30">
                <div className="text-sm text-gray-400 mb-2">Out of Stock</div>
                <div className="text-2xl font-bold text-red-400">6</div>
                <div className="text-xs text-gray-500 mt-1">Unavailable items</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Feature Highlights */}
      <section className="py-20 lg:py-32 bg-muted/30">
        <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12">
          <div className="text-center mb-16">
            <h2 className="text-4xl lg:text-5xl font-bold mb-4">Powerful Features</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Everything you need to manage inventory efficiently
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                icon: Warehouse,
                title: "Multi-Warehouse Management",
                description: "Manage stock across multiple locations with centralized control and real-time synchronization.",
              },
              {
                icon: Zap,
                title: "Stock Automation",
                description: "Automate reordering, stock transfers, and inventory updates to save time and reduce errors.",
              },
              {
                icon: Barcode,
                title: "Barcode Scanning",
                description: "Quick and accurate inventory tracking with built-in barcode scanning capabilities.",
              },
              {
                icon: Package,
                title: "Order Lifecycle Tracking",
                description: "Track orders from packed → shipped → delivered with complete visibility.",
              },
              {
                icon: Bell,
                title: "Low-Stock Alerts",
                description: "Automatic notifications when items reach critical stock levels or reorder points.",
              },
              {
                icon: TrendingUp,
                title: "Analytics & Revenue Reports",
                description: "Deep insights into inventory trends, sales patterns, and revenue optimization.",
              },
            ].map((feature, idx) => (
              <div
                key={idx}
                className="p-8 rounded-xl border border-border bg-card hover:shadow-lg transition-shadow"
              >
                <div className="h-12 w-12 rounded-lg bg-blue-100 dark:bg-blue-950 flex items-center justify-center mb-4">
                  <feature.icon className="h-6 w-6 text-blue-600" />
                </div>
                <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
                <p className="text-sm text-muted-foreground">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Mobile App Preview */}
      <section className="py-20 lg:py-32 bg-background">
        <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12">
          <div className="text-center mb-16">
            <h2 className="text-4xl lg:text-5xl font-bold mb-4">Mobile App</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Full-featured inventory management in your pocket
            </p>
          </div>

          <div className="flex justify-center">
            <div className="max-w-sm rounded-2xl overflow-hidden shadow-2xl border-4 border-border">
              <img
                src={mobileAppImage}
                alt="Mobile App"
                className="w-full h-auto"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-foreground text-background py-16">
        <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12">
          <div className="grid grid-cols-1 md:grid-cols-5 gap-8 mb-12">
            {/* Brand */}
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Package className="h-6 w-6" />
                <span className="text-lg font-bold">StockMaster</span>
              </div>
              <p className="text-sm text-background/80">
                Modern inventory management for businesses of all sizes.
              </p>
            </div>

            {/* Links */}
            {[
              {
                title: "Product",
                links: ["Features", "Pricing", "Security", "Roadmap"],
              },
              {
                title: "Resources",
                links: ["Documentation", "Help Center", "API Docs", "Blog"],
              },
              {
                title: "Company",
                links: ["About", "Careers", "Contact", "Press"],
              },
              {
                title: "Legal",
                links: ["Privacy", "Terms", "Cookies", "Compliance"],
              },
            ].map((col, idx) => (
              <div key={idx}>
                <h4 className="font-semibold mb-4">{col.title}</h4>
                <ul className="space-y-2">
                  {col.links.map((link, i) => (
                    <li key={i}>
                      <a href="#" className="text-sm text-background/80 hover:text-background">
                        {link}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          {/* Social & Copyright */}
          <div className="border-t border-background/20 pt-8">
            <div className="flex justify-between items-center flex-wrap gap-4 mb-4">
              <p className="text-sm text-background/80">
                &copy; 2025 StockMaster. All rights reserved.
              </p>
              <div className="flex gap-4">
                {[Github, Twitter, Linkedin, Facebook].map((Icon, idx) => (
                  <a
                    key={idx}
                    href="#"
                    className="text-background/80 hover:text-background transition-colors"
                  >
                    <Icon className="h-5 w-5" />
                  </a>
                ))}
              </div>
            </div>
            <p className="text-xs text-background/60">
              Made by Aarya Gosavi, Janhvi Shintre and Riya Duddalwar
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
