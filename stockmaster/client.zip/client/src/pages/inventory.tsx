import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { InventoryTable, InventoryItem } from "@/components/inventory-table";
import { InventoryForm } from "@/components/inventory-form";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import type { InventoryItem as APIInventoryItem } from "@shared/schema";

export default function Inventory() {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<InventoryItem | null>(null);
  const [currency, setCurrency] = useState(() => {
    return localStorage.getItem("currency") || "INR";
  });
  const { toast } = useToast();

  useEffect(() => {
    const handleStorageChange = () => {
      const newCurrency = localStorage.getItem("currency") || "INR";
      setCurrency(newCurrency);
    };
    window.addEventListener("storage", handleStorageChange);
    return () => window.removeEventListener("storage", handleStorageChange);
  }, []);

  const { data: items = [], isLoading, error } = useQuery<APIInventoryItem[]>({
    queryKey: ["/api/inventory"],
  });

  if (error && isUnauthorizedError(error)) {
    window.location.href = "/api/login";
  }

  const createMutation = useMutation({
    mutationFn: async (values: any) => {
      const res = await apiRequest("POST", "/api/inventory", values);
      return res.json();
    },
    onSuccess: (data) => {
      // Invalidate all related queries to sync across pages
      queryClient.invalidateQueries({ queryKey: ["/api/inventory"] });
      queryClient.invalidateQueries({ queryKey: ["/api/analytics"] });
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/alerts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/profit"] });
      toast({
        title: "Item added",
        description: `${data.name} has been added to inventory.`,
      });
      setDialogOpen(false);
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        window.location.href = "/api/login";
      } else {
        toast({
          title: "Error",
          description: "Failed to add item. Please try again.",
          variant: "destructive",
        });
      }
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, values }: { id: string; values: any }) => {
      const res = await apiRequest("PATCH", `/api/inventory/${id}`, values);
      return res.json();
    },
    onSuccess: (data) => {
      // Invalidate all related queries to sync across pages
      queryClient.invalidateQueries({ queryKey: ["/api/inventory"] });
      queryClient.invalidateQueries({ queryKey: ["/api/analytics"] });
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/alerts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/profit"] });
      toast({
        title: "Item updated",
        description: `${data.name} has been updated successfully.`,
      });
      setDialogOpen(false);
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        window.location.href = "/api/login";
      } else {
        toast({
          title: "Error",
          description: "Failed to update item. Please try again.",
          variant: "destructive",
        });
      }
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/inventory/${id}`);
    },
    onSuccess: () => {
      // Invalidate all related queries to sync across pages
      queryClient.invalidateQueries({ queryKey: ["/api/inventory"] });
      queryClient.invalidateQueries({ queryKey: ["/api/analytics"] });
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/alerts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/profit"] });
      toast({
        title: "Item deleted",
        description: "Item has been removed from inventory.",
      });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        window.location.href = "/api/login";
      } else {
        toast({
          title: "Error",
          description: "Failed to delete item. Please try again.",
          variant: "destructive",
        });
      }
    },
  });

  const handleAdd = () => {
    setEditingItem(null);
    setDialogOpen(true);
  };

  const handleEdit = (item: InventoryItem) => {
    setEditingItem(item);
    setDialogOpen(true);
  };

  const handleDelete = (item: InventoryItem) => {
    deleteMutation.mutate(item.id);
  };

  const handleSubmit = (values: any) => {
    if (editingItem) {
      updateMutation.mutate({ id: editingItem.id, values });
    } else {
      createMutation.mutate(values);
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-semibold">Inventory Management</h1>
          <p className="text-muted-foreground">
            View and manage all inventory items across warehouses
          </p>
        </div>
        <div className="text-center py-8">Loading inventory...</div>
      </div>
    );
  }

  const formattedItems = (items || []).map((item: APIInventoryItem) => ({
    ...item,
    lastUpdated: new Date(item.lastUpdated).toISOString().split("T")[0],
    price: Number(item.price),
  }));

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold">Inventory Management</h1>
        <p className="text-muted-foreground">
          View and manage all inventory items across warehouses
        </p>
      </div>

      <InventoryTable
        items={formattedItems}
        onAdd={handleAdd}
        onEdit={handleEdit}
        onDelete={handleDelete}
      />

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingItem ? "Edit Item" : "Add New Item"}
            </DialogTitle>
            <DialogDescription>
              {editingItem
                ? "Update the details of this inventory item."
                : "Add a new item to your inventory system."}
            </DialogDescription>
          </DialogHeader>
          <InventoryForm
            initialValues={editingItem || undefined}
            onSubmit={handleSubmit}
            onCancel={() => setDialogOpen(false)}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}
