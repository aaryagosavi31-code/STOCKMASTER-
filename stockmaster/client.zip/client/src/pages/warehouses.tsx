import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { MapPin, Package, Users, Phone } from "lucide-react";

const warehouses = [
  {
    id: "warehouse-1",
    name: "Warehouse A",
    location: "Mumbai, Maharashtra",
    address: "123 Industrial Area, Mumbai 400001",
    capacity: 50000,
    currentStock: 35000,
    manager: "Rajesh Kumar",
    phone: "+91-22-1234-5678",
    email: "rajesh.warehouse@stockflow.com",
    status: "active",
  },
  {
    id: "warehouse-2",
    name: "Warehouse B",
    location: "Delhi, NCR",
    address: "456 Logistics Hub, New Delhi 110015",
    capacity: 60000,
    currentStock: 48000,
    manager: "Priya Sharma",
    phone: "+91-11-8901-2345",
    email: "priya.warehouse@stockflow.com",
    status: "active",
  },
  {
    id: "warehouse-3",
    name: "Warehouse C",
    location: "Bangalore, Karnataka",
    address: "789 Tech Park, Bangalore 560034",
    capacity: 45000,
    currentStock: 32000,
    manager: "Amit Patel",
    phone: "+91-80-5678-9012",
    email: "amit.warehouse@stockflow.com",
    status: "active",
  },
];

export default function Warehouses() {
  const totalCapacity = warehouses.reduce((sum, w) => sum + w.capacity, 0);
  const totalStock = warehouses.reduce((sum, w) => sum + w.currentStock, 0);
  const utilizationPercentage = ((totalStock / totalCapacity) * 100).toFixed(1);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold">Warehouses</h1>
        <p className="text-muted-foreground">View and manage all warehouse locations and inventory</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Warehouses</p>
                <p className="text-2xl font-bold">{warehouses.length}</p>
              </div>
              <MapPin className="h-8 w-8 text-primary opacity-70" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Capacity</p>
                <p className="text-2xl font-bold">{(totalCapacity / 1000).toFixed(1)}K units</p>
              </div>
              <Package className="h-8 w-8 text-primary opacity-70" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Utilization</p>
                <p className="text-2xl font-bold">{utilizationPercentage}%</p>
              </div>
              <div className="text-sm text-muted-foreground">
                {totalStock}K / {totalCapacity}K
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 gap-6">
        {warehouses.map((warehouse) => {
          const utilization = ((warehouse.currentStock / warehouse.capacity) * 100).toFixed(1);
          return (
            <Card key={warehouse.id} className="hover-elevate" data-testid={`card-warehouse-${warehouse.id}`}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle>{warehouse.name}</CardTitle>
                    <CardDescription className="flex items-center gap-2 mt-2">
                      <MapPin className="h-4 w-4" />
                      {warehouse.location}
                    </CardDescription>
                  </div>
                  <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200 dark:bg-green-950 dark:text-green-50 dark:border-green-800">
                    {warehouse.status}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <p className="text-sm text-muted-foreground mb-3">Address</p>
                      <p className="font-medium">{warehouse.address}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground mb-3">Capacity Usage</p>
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-sm font-medium">
                            {warehouse.currentStock.toLocaleString()} / {warehouse.capacity.toLocaleString()} units
                          </span>
                          <span className="text-sm font-semibold text-primary">{utilization}%</span>
                        </div>
                        <div className="w-full bg-muted rounded-full h-2">
                          <div
                            className="bg-primary rounded-full h-2 transition-all"
                            style={{ width: `${utilization}%` }}
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="border-t pt-4 grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div>
                      <div className="flex items-center gap-2 mb-2">
                        <Users className="h-4 w-4 text-muted-foreground" />
                        <p className="text-sm text-muted-foreground">Manager</p>
                      </div>
                      <p className="font-medium">{warehouse.manager}</p>
                      <p className="text-sm text-muted-foreground">{warehouse.email}</p>
                    </div>
                    <div>
                      <div className="flex items-center gap-2 mb-2">
                        <Phone className="h-4 w-4 text-muted-foreground" />
                        <p className="text-sm text-muted-foreground">Contact</p>
                      </div>
                      <p className="font-medium">{warehouse.phone}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground mb-2">Quick Stats</p>
                      <div className="space-y-1">
                        <p className="text-sm">
                          <span className="text-muted-foreground">Active:</span> Yes
                        </p>
                        <p className="text-sm">
                          <span className="text-muted-foreground">Status:</span> Operational
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
