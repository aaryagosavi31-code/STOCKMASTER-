import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { DollarSign, TrendingUp, TrendingDown, Clock, AlertCircle } from "lucide-react";
import { formatCurrency } from "@/lib/currency";
import { isUnauthorizedError } from "@/lib/authUtils";
import { useLanguage } from "@/components/language-provider";
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";

interface FinancialData {
  totalRevenue: number;
  totalExpenses: number;
  netProfit: number;
  pendingTransactions: number;
  pendingAmount: number;
  monthlyRevenue: Array<{ month: string; revenue: number; expenses: number }>;
  profitByCategory: Array<{ category: string; profit: number }>;
}

export default function Profit() {
  const { currency } = useLanguage();

  const { data: financialData, isLoading } = useQuery<FinancialData>({
    queryKey: ["/api/financial"],
  });

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-semibold">Profit & Revenue</h1>
          <p className="text-muted-foreground">Financial accounting and performance analysis</p>
        </div>
        <div className="text-center py-8">Loading financial data...</div>
      </div>
    );
  }

  // Mock data for demonstration
  const mockData: FinancialData = financialData || {
    totalRevenue: 450000,
    totalExpenses: 280000,
    netProfit: 170000,
    pendingTransactions: 12,
    pendingAmount: 45000,
    monthlyRevenue: [
      { month: "Jan", revenue: 35000, expenses: 22000 },
      { month: "Feb", revenue: 38000, expenses: 24000 },
      { month: "Mar", revenue: 42000, expenses: 25000 },
      { month: "Apr", revenue: 45000, expenses: 26000 },
      { month: "May", revenue: 48000, expenses: 27000 },
      { month: "Jun", revenue: 50000, expenses: 28000 },
    ],
    profitByCategory: [
      { category: "Electronics", profit: 65000 },
      { category: "Furniture", profit: 52000 },
      { category: "Clothing", profit: 38000 },
      { category: "Other", profit: 15000 },
    ],
  };

  const colors = ["#3b82f6", "#10b981", "#f59e0b", "#ef4444"];
  const profitPercentage = ((mockData.netProfit / mockData.totalRevenue) * 100).toFixed(2);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-semibold">Profit & Revenue</h1>
        <p className="text-muted-foreground">
          Financial accounting and performance analysis
        </p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
            <TrendingUp className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {formatCurrency(mockData.totalRevenue, currency)}
            </div>
            <p className="text-xs text-muted-foreground mt-1">From all sales</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Expenses</CardTitle>
            <TrendingDown className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {formatCurrency(mockData.totalExpenses, currency)}
            </div>
            <p className="text-xs text-muted-foreground mt-1">Operating costs</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Net Profit</CardTitle>
            <DollarSign className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {formatCurrency(mockData.netProfit, currency)}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {profitPercentage}% profit margin
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Amount</CardTitle>
            <Clock className="h-4 w-4 text-yellow-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {formatCurrency(mockData.pendingAmount, currency)}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {mockData.pendingTransactions} pending
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Revenue vs Expenses */}
        <Card>
          <CardHeader>
            <CardTitle>Monthly Revenue vs Expenses</CardTitle>
            <CardDescription>6-month financial overview</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={mockData.monthlyRevenue}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip formatter={(value: any) => formatCurrency(Number(value), currency)} />
                <Legend />
                <Line
                  type="monotone"
                  dataKey="revenue"
                  stroke="#10b981"
                  name="Revenue"
                  strokeWidth={2}
                />
                <Line
                  type="monotone"
                  dataKey="expenses"
                  stroke="#ef4444"
                  name="Expenses"
                  strokeWidth={2}
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Profit by Category */}
        <Card>
          <CardHeader>
            <CardTitle>Profit Distribution by Category</CardTitle>
            <CardDescription>Revenue breakdown</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={mockData.profitByCategory}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ category, profit }) =>
                    `${category}: ${formatCurrency(profit, currency)}`
                  }
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="profit"
                >
                  {mockData.profitByCategory.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={colors[index % colors.length]} />
                  ))}
                </Pie>
                <Tooltip formatter={(value: any) => formatCurrency(Number(value), currency)} />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Accounting Details */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Profit/Loss Accounting */}
        <Card>
          <CardHeader>
            <CardTitle>Profit & Loss Statement</CardTitle>
            <CardDescription>Current period accounting</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className="flex justify-between items-center pb-2 border-b">
                <span className="text-sm font-medium">Total Revenue</span>
                <span className="font-semibold text-green-600">
                  {formatCurrency(mockData.totalRevenue, currency)}
                </span>
              </div>
              <div className="flex justify-between items-center pb-2 border-b">
                <span className="text-sm font-medium">Cost of Goods Sold</span>
                <span className="font-semibold text-red-600">
                  -{formatCurrency(mockData.totalExpenses * 0.6, currency)}
                </span>
              </div>
              <div className="flex justify-between items-center pb-2 border-b">
                <span className="text-sm font-medium">Operating Expenses</span>
                <span className="font-semibold text-red-600">
                  -{formatCurrency(mockData.totalExpenses * 0.4, currency)}
                </span>
              </div>
              <div className="flex justify-between items-center pt-2 bg-blue-50 dark:bg-blue-950 p-3 rounded">
                <span className="font-semibold">Net Profit</span>
                <span className="text-lg font-bold text-blue-600">
                  {formatCurrency(mockData.netProfit, currency)}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Pending Transactions */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5" />
              Pending Transactions
            </CardTitle>
            <CardDescription>Awaiting payment or confirmation</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              {[
                { id: 1, description: "Invoice #1001 - Customer ABC", amount: 15000 },
                { id: 2, description: "Purchase Order #502 - Supplier XYZ", amount: 12000 },
                { id: 3, description: "Invoice #1002 - Customer DEF", amount: 10000 },
                { id: 4, description: "Refund - Order #456", amount: -8000 },
              ].map((transaction) => (
                <div
                  key={transaction.id}
                  className="flex justify-between items-center p-3 border rounded-lg hover:bg-slate-50 dark:hover:bg-slate-900"
                  data-testid={`pending-transaction-${transaction.id}`}
                >
                  <div className="flex-1">
                    <p className="text-sm font-medium">{transaction.description}</p>
                    <Badge variant="outline" className="mt-1">
                      <Clock className="h-3 w-3 mr-1" />
                      Pending
                    </Badge>
                  </div>
                  <span
                    className={`font-semibold ${
                      transaction.amount > 0 ? "text-green-600" : "text-red-600"
                    }`}
                  >
                    {transaction.amount > 0 ? "+" : ""}
                    {formatCurrency(Math.abs(transaction.amount), currency)}
                  </span>
                </div>
              ))}
              <div className="pt-3 border-t flex justify-between items-center bg-yellow-50 dark:bg-yellow-950 p-3 rounded">
                <span className="font-semibold">Total Pending</span>
                <span className="text-lg font-bold text-yellow-600">
                  {formatCurrency(mockData.pendingAmount, currency)}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Money Accounting */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertCircle className="h-5 w-5" />
            Detailed Money Accounting
          </CardTitle>
          <CardDescription>Complete financial breakdown</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="border-b">
                <tr className="bg-slate-50 dark:bg-slate-900">
                  <th className="px-4 py-3 text-left font-semibold">Account</th>
                  <th className="px-4 py-3 text-right font-semibold">Amount</th>
                  <th className="px-4 py-3 text-left font-semibold">Status</th>
                  <th className="px-4 py-3 text-left font-semibold">Category</th>
                </tr>
              </thead>
              <tbody>
                {[
                  {
                    account: "Sales Revenue",
                    amount: mockData.totalRevenue,
                    status: "Completed",
                    category: "Income",
                  },
                  {
                    account: "Cost of Goods Sold",
                    amount: -mockData.totalExpenses * 0.6,
                    status: "Completed",
                    category: "Expense",
                  },
                  {
                    account: "Operating Expenses",
                    amount: -mockData.totalExpenses * 0.4,
                    status: "Completed",
                    category: "Expense",
                  },
                  {
                    account: "Pending Transactions",
                    amount: mockData.pendingAmount,
                    status: "Pending",
                    category: "Pending",
                  },
                  {
                    account: "Net Profit (YTD)",
                    amount: mockData.netProfit,
                    status: "Calculated",
                    category: "Summary",
                  },
                ].map((row, idx) => (
                  <tr key={idx} className="border-b hover:bg-slate-50 dark:hover:bg-slate-900">
                    <td className="px-4 py-3 font-medium">{row.account}</td>
                    <td className="px-4 py-3 text-right font-semibold">
                      <span className={row.amount > 0 ? "text-green-600" : "text-red-600"}>
                        {row.amount > 0 ? "+" : ""}
                        {formatCurrency(Math.abs(row.amount), currency)}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <Badge
                        variant={
                          row.status === "Completed"
                            ? "default"
                            : row.status === "Pending"
                            ? "secondary"
                            : "outline"
                        }
                      >
                        {row.status}
                      </Badge>
                    </td>
                    <td className="px-4 py-3 text-sm text-muted-foreground">{row.category}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
