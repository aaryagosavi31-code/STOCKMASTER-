import { useState, useEffect } from "react";
import {
  StockTrendChart,
  CategoryDistributionChart,
  StockStatusChart,
  TopMovingItemsChart,
} from "@/components/analytics-charts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Download } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { formatCurrency } from "@/lib/currency";

export default function Analytics() {
  const [currency, setCurrency] = useState(() => {
    return localStorage.getItem("currency") || "INR";
  });
  const { toast } = useToast();

  useEffect(() => {
    const handleStorageChange = () => {
      const newCurrency = localStorage.getItem("currency") || "INR";
      setCurrency(newCurrency);
    };
    window.addEventListener("storage", handleStorageChange);
    return () => window.removeEventListener("storage", handleStorageChange);
  }, []);

  const handleExport = async () => {
    try {
      const res = await fetch("/api/export/inventory", {
        credentials: "include",
      });

      if (res.status === 401) {
        window.location.href = "/api/login";
        return;
      }

      if (!res.ok) {
        throw new Error("Failed to export data");
      }

      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "inventory.csv";
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);

      toast({
        title: "Export successful",
        description: "Inventory data has been exported to CSV.",
      });
    } catch (error) {
      toast({
        title: "Export failed",
        description: "Failed to export data. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-semibold">Analytics Dashboard</h1>
          <p className="text-muted-foreground">
            Interactive insights and trends for inventory performance
          </p>
        </div>
        <div className="flex gap-2 flex-wrap">
          <Select defaultValue="30">
            <SelectTrigger className="w-[180px]" data-testid="select-timerange">
              <SelectValue placeholder="Time range" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7">Last 7 days</SelectItem>
              <SelectItem value="30">Last 30 days</SelectItem>
              <SelectItem value="90">Last 90 days</SelectItem>
              <SelectItem value="365">Last year</SelectItem>
            </SelectContent>
          </Select>
          <Button onClick={handleExport} data-testid="button-export">
            <Download className="h-4 w-4 mr-2" />
            Export Data
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <StockTrendChart />
        <CategoryDistributionChart />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <TopMovingItemsChart />
        <StockStatusChart />
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Key Performance Indicators</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-2">
              <p className="text-sm font-medium text-muted-foreground">
                Average Stock Value
              </p>
              <p className="text-2xl font-bold">{formatCurrency(228.35, currency)}</p>
              <p className="text-xs text-muted-foreground">Per item</p>
            </div>
            <div className="space-y-2">
              <p className="text-sm font-medium text-muted-foreground">
                Stock Turnover Rate
              </p>
              <p className="text-2xl font-bold">4.2x</p>
              <p className="text-xs text-muted-foreground">Per year</p>
            </div>
            <div className="space-y-2">
              <p className="text-sm font-medium text-muted-foreground">
                Days of Inventory
              </p>
              <p className="text-2xl font-bold">87 days</p>
              <p className="text-xs text-muted-foreground">On average</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
