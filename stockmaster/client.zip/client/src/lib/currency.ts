// Exchange rates relative to USD (1 USD = X amount of other currency)
const EXCHANGE_RATES: Record<string, number> = {
  USD: 1,
  EUR: 0.92,
  GBP: 0.79,
  JPY: 110,
  CNY: 7.0,
  RUB: 117,
  KRW: 1100,
  INR: 83,
};

export function convertCurrency(
  value: number,
  fromCurrency: string = "USD",
  toCurrency: string = "USD"
): number {
  if (fromCurrency === toCurrency) {
    return value;
  }

  const fromRate = EXCHANGE_RATES[fromCurrency] || 1;
  const toRate = EXCHANGE_RATES[toCurrency] || 1;

  // Convert to USD first, then to target currency
  const valueInUSD = value / fromRate;
  return valueInUSD * toRate;
}

export function formatCurrency(
  value: number,
  currency: string = "USD",
  fromCurrency: string = "USD"
): string {
  // Convert the value from base currency to target currency
  const convertedValue = convertCurrency(value, fromCurrency, currency);

  const localeMap: Record<string, string> = {
    USD: "en-US",
    EUR: "de-DE",
    GBP: "en-GB",
    JPY: "ja-JP",
    CNY: "zh-CN",
    RUB: "ru-RU",
    KRW: "ko-KR",
    INR: "en-IN",
  };

  const locale = localeMap[currency] || "en-US";

  const formatter = new Intl.NumberFormat(locale, {
    style: "currency",
    currency: currency,
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  });

  return formatter.format(convertedValue);
}

export function getCurrencySymbol(currency: string = "USD"): string {
  const symbols: Record<string, string> = {
    USD: "$",
    EUR: "€",
    GBP: "£",
    JPY: "¥",
    CNY: "¥",
    RUB: "₽",
    KRW: "₩",
    INR: "₹",
  };
  return symbols[currency] || currency;
}
