import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowUpRight, ArrowDownLeft, ArrowLeftRight } from "lucide-react";
import { cn } from "@/lib/utils";

export interface Transaction {
  id: string;
  type: "in" | "out" | "transfer";
  itemName: string;
  quantity: number;
  user: string;
  timestamp: string;
  location?: string;
  reference?: string;
}

interface TransactionHistoryProps {
  transactions: Transaction[];
}

export function TransactionHistory({ transactions }: TransactionHistoryProps) {
  const getTransactionIcon = (type: Transaction["type"]) => {
    switch (type) {
      case "in":
        return <ArrowDownLeft className="h-4 w-4" />;
      case "out":
        return <ArrowUpRight className="h-4 w-4" />;
      case "transfer":
        return <ArrowLeftRight className="h-4 w-4" />;
    }
  };

  const getTransactionColor = (type: Transaction["type"]) => {
    switch (type) {
      case "in":
        return "text-green-600";
      case "out":
        return "text-red-600";
      case "transfer":
        return "text-blue-600";
    }
  };

  const getTransactionLabel = (type: Transaction["type"]) => {
    switch (type) {
      case "in":
        return "Stock In";
      case "out":
        return "Stock Out";
      case "transfer":
        return "Transfer";
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Recent Transactions</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {transactions.map((transaction, index) => (
            <div
              key={transaction.id}
              className={cn(
                "flex items-start gap-4 pb-4",
                index !== transactions.length - 1 && "border-b"
              )}
              data-testid={`transaction-${transaction.id}`}
            >
              <div
                className={cn(
                  "h-10 w-10 rounded-md flex items-center justify-center flex-shrink-0",
                  transaction.type === "in" && "bg-green-100 dark:bg-green-900/20",
                  transaction.type === "out" && "bg-red-100 dark:bg-red-900/20",
                  transaction.type === "transfer" && "bg-blue-100 dark:bg-blue-900/20"
                )}
              >
                <div className={getTransactionColor(transaction.type)}>
                  {getTransactionIcon(transaction.type)}
                </div>
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between gap-2 flex-wrap">
                  <div className="flex-1 min-w-0">
                    <p className="font-medium truncate">{transaction.itemName}</p>
                    <p className="text-sm text-muted-foreground">
                      {transaction.user} • {transaction.timestamp}
                    </p>
                    {transaction.location && (
                      <p className="text-xs text-muted-foreground mt-1">
                        {transaction.location}
                      </p>
                    )}
                  </div>
                  <div className="flex items-center gap-2 flex-shrink-0">
                    <Badge variant="secondary">
                      {transaction.type === "out" ? "-" : "+"}
                      {transaction.quantity}
                    </Badge>
                    <Badge variant="outline">{getTransactionLabel(transaction.type)}</Badge>
                  </div>
                </div>
                {transaction.reference && (
                  <p className="text-xs text-muted-foreground mt-1">
                    Ref: {transaction.reference}
                  </p>
                )}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
