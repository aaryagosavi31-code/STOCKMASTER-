import { Link } from "wouter";
import { Package } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ThemeToggle } from "@/components/theme-toggle";

export function LandingNavbar() {
  return (
    <nav className="border-b bg-background/95 backdrop-blur sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link href="/">
            <div className="flex items-center gap-2 cursor-pointer group">
              <div className="h-8 w-8 rounded-md bg-blue-600 flex items-center justify-center group-hover:shadow-lg transition-shadow">
                <Package className="h-5 w-5 text-white" />
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-blue-600 to-blue-500 bg-clip-text text-transparent">
                StockMaster
              </span>
            </div>
          </Link>

          {/* Navigation Tabs */}
          <div className="hidden lg:flex items-center gap-8">
            {["Features", "Solutions", "Pricing", "Customers", "Integrations", "Resources"].map(
              (item) => (
                <a
                  key={item}
                  href="#"
                  className="text-sm font-medium text-foreground/80 hover:text-foreground transition-colors"
                >
                  {item}
                </a>
              )
            )}
          </div>

          {/* Right Side Actions */}
          <div className="flex items-center gap-4">
            <ThemeToggle />
            <Link href="/login">
              <Button
                size="sm"
                className="bg-blue-600 hover:bg-blue-700 text-white rounded-full px-6"
                data-testid="button-login-navbar"
              >
                Log In
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
}
