import { InventoryForm } from "../inventory-form";

export default function InventoryFormExample() {
  return (
    <div className="p-6">
      <div className="max-w-3xl">
        <h2 className="text-2xl font-semibold mb-6">Add New Item</h2>
        <InventoryForm
          onSubmit={(values) => console.log("Form submitted:", values)}
          onCancel={() => console.log("Form cancelled")}
        />
      </div>
    </div>
  );
}
