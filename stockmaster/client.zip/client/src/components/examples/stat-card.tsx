import { StatCard } from "../stat-card";
import { Package, DollarSign, AlertTriangle, TrendingUp } from "lucide-react";

export default function StatCardExample() {
  return (
    <div className="p-6 space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title="Total Items"
          value="1,247"
          icon={Package}
          trend={{ value: 12.5, isPositive: true }}
          subtitle="Across all warehouses"
        />
        <StatCard
          title="Inventory Value"
          value="$284,560"
          icon={DollarSign}
          trend={{ value: 8.2, isPositive: true }}
        />
        <StatCard
          title="Low Stock Items"
          value="23"
          icon={AlertTriangle}
          trend={{ value: 5, isPositive: false }}
          subtitle="Requires attention"
        />
        <StatCard
          title="Monthly Turnover"
          value="64%"
          icon={TrendingUp}
          trend={{ value: 3.1, isPositive: true }}
        />
      </div>
    </div>
  );
}
