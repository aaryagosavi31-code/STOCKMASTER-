import { InventoryTable, InventoryItem } from "../inventory-table";

const mockItems: InventoryItem[] = [
  {
    id: "1",
    sku: "ELC-001",
    name: "Wireless Mouse",
    category: "Electronics",
    quantity: 145,
    minStock: 50,
    price: 29.99,
    location: "Warehouse A - Shelf 12",
    lastUpdated: "2024-01-15",
  },
  {
    id: "2",
    sku: "ELC-002",
    name: "USB-C Cable",
    category: "Electronics",
    quantity: 23,
    minStock: 30,
    price: 12.99,
    location: "Warehouse A - Shelf 8",
    lastUpdated: "2024-01-14",
  },
  {
    id: "3",
    sku: "FUR-001",
    name: "Office Chair",
    category: "Furniture",
    quantity: 0,
    minStock: 10,
    price: 249.99,
    location: "Warehouse B - Section 3",
    lastUpdated: "2024-01-10",
  },
  {
    id: "4",
    sku: "STA-001",
    name: "Notebook Set",
    category: "Stationery",
    quantity: 432,
    minStock: 100,
    price: 8.99,
    location: "Warehouse A - Shelf 15",
    lastUpdated: "2024-01-16",
  },
  {
    id: "5",
    sku: "ELC-003",
    name: "Mechanical Keyboard",
    category: "Electronics",
    quantity: 78,
    minStock: 25,
    price: 89.99,
    location: "Warehouse A - Shelf 12",
    lastUpdated: "2024-01-15",
  },
];

export default function InventoryTableExample() {
  return (
    <div className="p-6">
      <InventoryTable
        items={mockItems}
        onAdd={() => console.log("Add item")}
        onEdit={(item) => console.log("Edit item:", item)}
        onDelete={(item) => console.log("Delete item:", item)}
      />
    </div>
  );
}
