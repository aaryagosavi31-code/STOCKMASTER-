import { TransactionHistory, Transaction } from "../transaction-history";

const mockTransactions: Transaction[] = [
  {
    id: "1",
    type: "in",
    itemName: "Wireless Mouse",
    quantity: 50,
    user: "Sarah Johnson",
    timestamp: "2 hours ago",
    location: "Warehouse A - Shelf 12",
    reference: "PO-2024-001",
  },
  {
    id: "2",
    type: "out",
    itemName: "USB-C Cable",
    quantity: 25,
    user: "Mike Chen",
    timestamp: "5 hours ago",
    location: "Warehouse A - Shelf 8",
    reference: "SO-2024-145",
  },
  {
    id: "3",
    type: "transfer",
    itemName: "Office Chair",
    quantity: 10,
    user: "John Doe",
    timestamp: "1 day ago",
    location: "A-Shelf 3 → B-Section 3",
    reference: "TR-2024-089",
  },
  {
    id: "4",
    type: "in",
    itemName: "Mechanical Keyboard",
    quantity: 30,
    user: "Sarah Johnson",
    timestamp: "2 days ago",
    location: "Warehouse A - Shelf 12",
    reference: "PO-2024-002",
  },
  {
    id: "5",
    type: "out",
    itemName: "Notebook Set",
    quantity: 100,
    user: "David Park",
    timestamp: "3 days ago",
    location: "Warehouse A - Shelf 15",
    reference: "SO-2024-142",
  },
];

export default function TransactionHistoryExample() {
  return (
    <div className="p-6">
      <TransactionHistory transactions={mockTransactions} />
    </div>
  );
}
