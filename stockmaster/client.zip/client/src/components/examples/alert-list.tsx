import { AlertList, Alert } from "../alert-list";

const mockAlerts: Alert[] = [
  {
    id: "1",
    type: "out_of_stock",
    itemName: "Office Chair",
    sku: "FUR-001",
    currentStock: 0,
    minStock: 10,
    timestamp: "2 hours ago",
    severity: "high",
  },
  {
    id: "2",
    type: "low_stock",
    itemName: "USB-C Cable",
    sku: "ELC-002",
    currentStock: 23,
    minStock: 30,
    timestamp: "5 hours ago",
    severity: "medium",
  },
  {
    id: "3",
    type: "low_stock",
    itemName: "Notebook Set",
    sku: "STA-001",
    currentStock: 105,
    minStock: 100,
    timestamp: "1 day ago",
    severity: "low",
  },
];

export default function AlertListExample() {
  return (
    <div className="p-6">
      <AlertList
        alerts={mockAlerts}
        onResolve={(alert) => console.log("Resolve alert:", alert)}
        onDismiss={(alert) => console.log("Dismiss alert:", alert)}
      />
    </div>
  );
}
