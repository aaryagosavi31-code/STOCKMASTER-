import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Plus } from "lucide-react";

interface CreatePurchaseOrderProps {
  onOrderCreated: (order: any) => void;
}

export function CreatePurchaseOrderDialog({ onOrderCreated }: CreatePurchaseOrderProps) {
  const [open, setOpen] = useState(false);
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    supplierName: "",
    supplierCompany: "",
    supplierEmail: "",
    supplierPhone: "",
    productName: "",
    quantity: "",
    costPerUnit: "",
    totalAmount: "",
    deliveryWarehouse: "",
    deliveryDate: "",
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => {
      const updated = { ...prev, [name]: value };

      // Auto-calculate total amount
      if (name === "quantity" || name === "costPerUnit") {
        const qty = parseFloat(updated.quantity) || 0;
        const cost = parseFloat(updated.costPerUnit) || 0;
        updated.totalAmount = (qty * cost).toFixed(2);
      }

      return updated;
    });
  };

  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Validation
    if (
      !formData.supplierName ||
      !formData.productName ||
      !formData.quantity ||
      !formData.costPerUnit ||
      !formData.deliveryWarehouse ||
      !formData.deliveryDate
    ) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }

    // Create new order
    const newOrder = {
      id: `PO${String(Date.now()).slice(-6)}`,
      date: new Date().toISOString().split("T")[0],
      status: "pending",
      quantity: parseInt(formData.quantity),
      amount: parseFloat(formData.totalAmount),
      items: formData.productName,
      deliveryDate: formData.deliveryDate,
      deliveryLocation: getWarehouseLocation(formData.deliveryWarehouse),
      supplier: {
        name: formData.supplierName,
        company: formData.supplierCompany || formData.supplierName,
        email: formData.supplierEmail,
        phone: formData.supplierPhone,
        contactPerson: formData.supplierName,
      },
      bank: {
        accountName: formData.supplierCompany || formData.supplierName,
        accountNumber: "XXXXXXXXXX",
        ifsc: "XXXXX0000",
        bankName: "To be provided by supplier",
      },
      location: {
        address: "Supplier address to be confirmed",
        city: "City",
        state: "State",
        pincode: "000000",
      },
      paymentTerms: "To be negotiated",
      specifications: `${formData.productName} - Qty: ${formData.quantity} units`,
      warehouse: formData.deliveryWarehouse,
    };

    onOrderCreated(newOrder);

    toast({
      title: "Purchase Order Created",
      description: `PO ${newOrder.id} created successfully for ${formData.productName}`,
    });

    // Reset form and close dialog
    setFormData({
      supplierName: "",
      supplierCompany: "",
      supplierEmail: "",
      supplierPhone: "",
      productName: "",
      quantity: "",
      costPerUnit: "",
      totalAmount: "",
      deliveryWarehouse: "",
      deliveryDate: "",
    });
    setOpen(false);
  };

  const getWarehouseLocation = (warehouseId: string): string => {
    const warehouses: Record<string, string> = {
      "warehouse-1": "Mumbai, Maharashtra",
      "warehouse-2": "Delhi, NCR",
      "warehouse-3": "Bangalore, Karnataka",
    };
    return warehouses[warehouseId] || "Unknown Location";
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button data-testid="button-create-purchase-order" className="gap-2">
          <Plus className="h-4 w-4" />
          Create Purchase Order
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto" data-testid="dialog-create-purchase">
        <DialogHeader>
          <DialogTitle>Create Custom Purchase Order</DialogTitle>
          <DialogDescription>
            Add a new purchase order with product details and warehouse delivery location
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Supplier Information */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Supplier Information</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="supplierName">
                  Supplier Name <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="supplierName"
                  name="supplierName"
                  placeholder="e.g., Rahul Electronics"
                  value={formData.supplierName}
                  onChange={handleInputChange}
                  data-testid="input-supplier-name"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="supplierCompany">Supplier Company</Label>
                <Input
                  id="supplierCompany"
                  name="supplierCompany"
                  placeholder="e.g., Rahul Electronics Co. Ltd."
                  value={formData.supplierCompany}
                  onChange={handleInputChange}
                  data-testid="input-supplier-company"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="supplierEmail">Supplier Email</Label>
                <Input
                  id="supplierEmail"
                  name="supplierEmail"
                  placeholder="email@supplier.com"
                  type="email"
                  value={formData.supplierEmail}
                  onChange={handleInputChange}
                  data-testid="input-supplier-email"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="supplierPhone">Supplier Phone</Label>
                <Input
                  id="supplierPhone"
                  name="supplierPhone"
                  placeholder="+91-98765-43210"
                  value={formData.supplierPhone}
                  onChange={handleInputChange}
                  data-testid="input-supplier-phone"
                />
              </div>
            </div>
          </div>

          {/* Product Information */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Product Details</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="productName">
                  Product Name <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="productName"
                  name="productName"
                  placeholder="e.g., Smart Devices, Office Chairs"
                  value={formData.productName}
                  onChange={handleInputChange}
                  data-testid="input-product-name"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="quantity">
                  Quantity (units) <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="quantity"
                  name="quantity"
                  type="number"
                  placeholder="100"
                  value={formData.quantity}
                  onChange={handleInputChange}
                  data-testid="input-quantity"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="costPerUnit">
                  Cost per Unit <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="costPerUnit"
                  name="costPerUnit"
                  type="number"
                  step="0.01"
                  placeholder="500"
                  value={formData.costPerUnit}
                  onChange={handleInputChange}
                  data-testid="input-cost-per-unit"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="totalAmount">Total Amount</Label>
                <Input
                  id="totalAmount"
                  name="totalAmount"
                  type="text"
                  placeholder="Auto-calculated"
                  value={formData.totalAmount}
                  disabled
                  className="bg-muted"
                  data-testid="input-total-amount"
                />
              </div>
            </div>
          </div>

          {/* Delivery Information */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Delivery Details</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="deliveryWarehouse">
                  Deliver to Warehouse <span className="text-red-500">*</span>
                </Label>
                <Select
                  value={formData.deliveryWarehouse}
                  onValueChange={(value) =>
                    handleSelectChange("deliveryWarehouse", value)
                  }
                >
                  <SelectTrigger
                    id="deliveryWarehouse"
                    data-testid="select-delivery-warehouse"
                  >
                    <SelectValue placeholder="Select warehouse" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="warehouse-1">
                      Warehouse A - Mumbai
                    </SelectItem>
                    <SelectItem value="warehouse-2">
                      Warehouse B - Delhi
                    </SelectItem>
                    <SelectItem value="warehouse-3">
                      Warehouse C - Bangalore
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="deliveryDate">
                  Expected Delivery Date <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="deliveryDate"
                  name="deliveryDate"
                  type="date"
                  value={formData.deliveryDate}
                  onChange={handleInputChange}
                  data-testid="input-delivery-date"
                />
              </div>
            </div>
          </div>

          <div className="flex gap-3 pt-4">
            <Button
              type="submit"
              className="flex-1"
              data-testid="button-submit-purchase-order"
            >
              Create Purchase Order
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={() => setOpen(false)}
              data-testid="button-cancel-purchase-order"
            >
              Cancel
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
