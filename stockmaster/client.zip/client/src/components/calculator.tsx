import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { X } from "lucide-react";

interface CalculatorProps {
  onClose?: () => void;
}

export function Calculator({ onClose }: CalculatorProps) {
  const [display, setDisplay] = useState("0");
  const [previousValue, setPreviousValue] = useState<number | null>(null);
  const [operation, setOperation] = useState<string | null>(null);
  const [newNumber, setNewNumber] = useState(true);

  const handleNumber = (num: string) => {
    if (newNumber) {
      setDisplay(num);
      setNewNumber(false);
    } else {
      setDisplay(display === "0" ? num : display + num);
    }
  };

  const handleOperation = (op: string) => {
    const currentValue = parseFloat(display);
    
    if (previousValue === null) {
      setPreviousValue(currentValue);
    } else if (operation) {
      const result = performCalculation(previousValue, currentValue, operation);
      setDisplay(String(result));
      setPreviousValue(result);
    }
    
    setOperation(op);
    setNewNumber(true);
  };

  const performCalculation = (prev: number, curr: number, op: string): number => {
    switch (op) {
      case "+":
        return prev + curr;
      case "-":
        return prev - curr;
      case "*":
        return prev * curr;
      case "/":
        return prev / curr;
      default:
        return curr;
    }
  };

  const handleEquals = () => {
    if (operation && previousValue !== null) {
      const result = performCalculation(previousValue, parseFloat(display), operation);
      setDisplay(result % 1 === 0 ? String(Math.round(result)) : String(result.toFixed(4)));
      setPreviousValue(null);
      setOperation(null);
      setNewNumber(true);
    }
  };

  const handleClear = () => {
    setDisplay("0");
    setPreviousValue(null);
    setOperation(null);
    setNewNumber(true);
  };

  const handleBackspace = () => {
    if (newNumber) return;
    if (display.length === 1) {
      setDisplay("0");
      setNewNumber(true);
    } else {
      setDisplay(display.slice(0, -1));
    }
  };

  const handleDecimal = () => {
    if (newNumber) {
      setDisplay("0.");
      setNewNumber(false);
    } else if (!display.includes(".")) {
      setDisplay(display + ".");
    }
  };

  const buttons = [
    ["7", "8", "9", "÷"],
    ["4", "5", "6", "×"],
    ["1", "2", "3", "−"],
    ["0", ".", "=", "+"],
  ];

  return (
    <div className="w-full max-w-sm bg-gradient-to-br from-slate-900 to-slate-800 rounded-xl shadow-2xl overflow-hidden border border-slate-700">
      <div className="flex items-center justify-between p-4 bg-slate-950 border-b border-slate-700">
        <h2 className="text-white font-bold text-lg flex items-center gap-2">
          🧮 Scientific Calculator
        </h2>
        {onClose && (
          <Button variant="ghost" size="icon" onClick={onClose} data-testid="button-close-calc" className="text-slate-400 hover:text-white">
            <X className="h-4 w-4" />
          </Button>
        )}
      </div>
      <div className="p-4 space-y-4 bg-slate-900">
        <div className="bg-slate-950 rounded-lg p-4 border border-slate-700">
          <Input
            type="text"
            value={display}
            readOnly
            className="w-full text-right text-3xl font-mono font-bold bg-slate-900 text-emerald-400 border-0 focus-visible:ring-0 placeholder:text-slate-600"
            data-testid="input-calculator-display"
          />
        </div>

        <div className="space-y-2">
          {buttons.map((row, i) => (
            <div key={i} className="grid grid-cols-4 gap-3">
              {row.map((btn) => {
                let op = btn;
                if (btn === "÷") op = "/";
                if (btn === "×") op = "*";
                if (btn === "−") op = "-";
                
                const isOperator = ["+", "−", "×", "÷"].includes(btn);
                const isEquals = btn === "=";
                
                return (
                  <Button
                    key={btn}
                    onClick={() => {
                      if (btn === "=") handleEquals();
                      else if (btn === ".") handleDecimal();
                      else if (isOperator) handleOperation(op);
                      else handleNumber(btn);
                    }}
                    className={`h-14 text-lg font-semibold rounded-lg border-0 transition-all ${
                      isEquals
                        ? "bg-emerald-500 hover:bg-emerald-600 text-white shadow-lg"
                        : isOperator
                        ? "bg-orange-500 hover:bg-orange-600 text-white shadow-lg"
                        : "bg-slate-700 hover:bg-slate-600 text-white shadow-md"
                    }`}
                    data-testid={`button-calc-${btn.replace("÷", "div").replace("×", "mul").replace("−", "sub")}`}
                  >
                    {btn}
                  </Button>
                );
              })}
            </div>
          ))}
          <Button
            onClick={handleClear}
            className="w-full h-12 bg-red-600 hover:bg-red-700 text-white font-semibold rounded-lg shadow-lg"
            data-testid="button-calc-clear"
          >
            Clear All
          </Button>
        </div>
      </div>
    </div>
  );
}
