import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface CreateTransactionOrderDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onOrderCreated: (order: any) => void;
}

export function CreateTransactionOrderDialog({
  open,
  onOpenChange,
  onOrderCreated,
}: CreateTransactionOrderDialogProps) {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    itemId: "",
    buyerName: "",
    buyerEmail: "",
    buyerPhone: "",
    buyerCompany: "",
    quantity: "",
    amount: "",
    status: "pending",
    deliveryAddress: "",
    deliveryCity: "",
    deliveryState: "",
    deliveryPincode: "",
    bankAccountName: "",
    bankAccountNumber: "",
    bankIfsc: "",
    bankName: "",
    notes: "",
  });

  const { data: items = [] } = useQuery({
    queryKey: ["/api/inventory"],
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (
      !formData.itemId ||
      !formData.buyerName ||
      !formData.buyerEmail ||
      !formData.quantity ||
      !formData.amount
    ) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    try {
      const res = await apiRequest("POST", "/api/orders", {
        ...formData,
        quantity: parseInt(formData.quantity),
        amount: parseFloat(formData.amount),
      });
      const order = await res.json();

      toast({
        title: "Order Created",
        description: "Transaction order has been created successfully",
      });

      onOrderCreated(order);
      onOpenChange(false);
      setFormData({
        itemId: "",
        buyerName: "",
        buyerEmail: "",
        buyerPhone: "",
        buyerCompany: "",
        quantity: "",
        amount: "",
        status: "pending",
        deliveryAddress: "",
        deliveryCity: "",
        deliveryState: "",
        deliveryPincode: "",
        bankAccountName: "",
        bankAccountNumber: "",
        bankIfsc: "",
        bankName: "",
        notes: "",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to create order. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto max-w-2xl">
        <DialogHeader>
          <DialogTitle>Create Transaction Order</DialogTitle>
          <DialogDescription>
            Add a new buyer order with delivery and payment details
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Item Selection */}
          <div className="space-y-2">
            <Label htmlFor="itemId" className="text-sm font-medium">
              Select Item *
            </Label>
            <Select
              value={formData.itemId}
              onValueChange={(value) => handleSelectChange("itemId", value)}
            >
              <SelectTrigger id="itemId" data-testid="select-order-item">
                <SelectValue placeholder="Choose an item" />
              </SelectTrigger>
              <SelectContent>
                {(items as any[])?.map((item: any) => (
                  <SelectItem key={item.id} value={item.id}>
                    {item.name} (SKU: {item.sku})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Buyer Information */}
          <div className="space-y-3 bg-muted/30 p-4 rounded-lg">
            <h3 className="font-semibold text-sm">Buyer Information</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div>
                <Label htmlFor="buyerName" className="text-xs">
                  Buyer Name *
                </Label>
                <Input
                  id="buyerName"
                  name="buyerName"
                  value={formData.buyerName}
                  onChange={handleChange}
                  placeholder="Enter buyer name"
                  data-testid="input-buyer-name"
                />
              </div>
              <div>
                <Label htmlFor="buyerCompany" className="text-xs">
                  Company
                </Label>
                <Input
                  id="buyerCompany"
                  name="buyerCompany"
                  value={formData.buyerCompany}
                  onChange={handleChange}
                  placeholder="Enter company name"
                  data-testid="input-buyer-company"
                />
              </div>
              <div>
                <Label htmlFor="buyerEmail" className="text-xs">
                  Email *
                </Label>
                <Input
                  id="buyerEmail"
                  name="buyerEmail"
                  type="email"
                  value={formData.buyerEmail}
                  onChange={handleChange}
                  placeholder="buyer@example.com"
                  data-testid="input-buyer-email"
                />
              </div>
              <div>
                <Label htmlFor="buyerPhone" className="text-xs">
                  Phone *
                </Label>
                <Input
                  id="buyerPhone"
                  name="buyerPhone"
                  value={formData.buyerPhone}
                  onChange={handleChange}
                  placeholder="+91-98765-43210"
                  data-testid="input-buyer-phone"
                />
              </div>
            </div>
          </div>

          {/* Order Details */}
          <div className="space-y-3 bg-muted/30 p-4 rounded-lg">
            <h3 className="font-semibold text-sm">Order Details</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div>
                <Label htmlFor="quantity" className="text-xs">
                  Quantity *
                </Label>
                <Input
                  id="quantity"
                  name="quantity"
                  type="number"
                  value={formData.quantity}
                  onChange={handleChange}
                  placeholder="0"
                  data-testid="input-quantity"
                />
              </div>
              <div>
                <Label htmlFor="amount" className="text-xs">
                  Amount *
                </Label>
                <Input
                  id="amount"
                  name="amount"
                  type="number"
                  step="0.01"
                  value={formData.amount}
                  onChange={handleChange}
                  placeholder="0.00"
                  data-testid="input-amount"
                />
              </div>
              <div className="md:col-span-2">
                <Label htmlFor="status" className="text-xs">
                  Status
                </Label>
                <Select
                  value={formData.status}
                  onValueChange={(value) =>
                    handleSelectChange("status", value)
                  }
                >
                  <SelectTrigger id="status" data-testid="select-order-status">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="confirmed">Confirmed</SelectItem>
                    <SelectItem value="in-transit">In Transit</SelectItem>
                    <SelectItem value="completed">Completed</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Delivery Information */}
          <div className="space-y-3 bg-muted/30 p-4 rounded-lg">
            <h3 className="font-semibold text-sm">Delivery Information</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div className="md:col-span-2">
                <Label htmlFor="deliveryAddress" className="text-xs">
                  Delivery Address
                </Label>
                <Input
                  id="deliveryAddress"
                  name="deliveryAddress"
                  value={formData.deliveryAddress}
                  onChange={handleChange}
                  placeholder="Street address"
                  data-testid="input-delivery-address"
                />
              </div>
              <div>
                <Label htmlFor="deliveryCity" className="text-xs">
                  City
                </Label>
                <Input
                  id="deliveryCity"
                  name="deliveryCity"
                  value={formData.deliveryCity}
                  onChange={handleChange}
                  placeholder="City"
                  data-testid="input-delivery-city"
                />
              </div>
              <div>
                <Label htmlFor="deliveryState" className="text-xs">
                  State
                </Label>
                <Input
                  id="deliveryState"
                  name="deliveryState"
                  value={formData.deliveryState}
                  onChange={handleChange}
                  placeholder="State"
                  data-testid="input-delivery-state"
                />
              </div>
              <div className="md:col-span-2">
                <Label htmlFor="deliveryPincode" className="text-xs">
                  Pincode
                </Label>
                <Input
                  id="deliveryPincode"
                  name="deliveryPincode"
                  value={formData.deliveryPincode}
                  onChange={handleChange}
                  placeholder="400001"
                  data-testid="input-delivery-pincode"
                />
              </div>
            </div>
          </div>

          {/* Bank Information */}
          <div className="space-y-3 bg-muted/30 p-4 rounded-lg">
            <h3 className="font-semibold text-sm">Bank Details</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div className="md:col-span-2">
                <Label htmlFor="bankAccountName" className="text-xs">
                  Account Name
                </Label>
                <Input
                  id="bankAccountName"
                  name="bankAccountName"
                  value={formData.bankAccountName}
                  onChange={handleChange}
                  placeholder="Account holder name"
                  data-testid="input-bank-account-name"
                />
              </div>
              <div>
                <Label htmlFor="bankAccountNumber" className="text-xs">
                  Account Number
                </Label>
                <Input
                  id="bankAccountNumber"
                  name="bankAccountNumber"
                  value={formData.bankAccountNumber}
                  onChange={handleChange}
                  placeholder="1234567890"
                  data-testid="input-bank-account-number"
                />
              </div>
              <div>
                <Label htmlFor="bankIfsc" className="text-xs">
                  IFSC Code
                </Label>
                <Input
                  id="bankIfsc"
                  name="bankIfsc"
                  value={formData.bankIfsc}
                  onChange={handleChange}
                  placeholder="HDFC0001234"
                  data-testid="input-bank-ifsc"
                />
              </div>
              <div className="md:col-span-2">
                <Label htmlFor="bankName" className="text-xs">
                  Bank Name
                </Label>
                <Input
                  id="bankName"
                  name="bankName"
                  value={formData.bankName}
                  onChange={handleChange}
                  placeholder="HDFC Bank"
                  data-testid="input-bank-name"
                />
              </div>
            </div>
          </div>

          {/* Additional Notes */}
          <div>
            <Label htmlFor="notes" className="text-xs">
              Notes
            </Label>
            <Input
              id="notes"
              name="notes"
              value={formData.notes}
              onChange={handleChange}
              placeholder="Additional notes or special instructions"
              data-testid="input-notes"
            />
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3 justify-end pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              data-testid="button-cancel-order"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={loading}
              data-testid="button-create-order"
            >
              {loading ? "Creating..." : "Create Order"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
