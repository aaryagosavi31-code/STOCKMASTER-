import { useState } from "react";
import { Calculator as CalcIcon, MessageCircle, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Calculator } from "@/components/calculator";
import { AIChatbot } from "@/components/ai-chatbot";

export function FloatingTools() {
  const [showCalculator, setShowCalculator] = useState(false);
  const [showChatbot, setShowChatbot] = useState(false);

  if (showCalculator || showChatbot) {
    return (
      <div className="fixed bottom-6 right-6 z-50 space-y-4">
        {showCalculator && (
          <div className="bg-background border rounded-lg shadow-lg">
            <Calculator onClose={() => setShowCalculator(false)} />
          </div>
        )}
        {showChatbot && (
          <div className="bg-background border rounded-lg shadow-lg">
            <AIChatbot onClose={() => setShowChatbot(false)} />
          </div>
        )}
        {!showCalculator && !showChatbot && (
          <div className="flex gap-2">
            <Button
              onClick={() => setShowCalculator(true)}
              size="icon"
              className="h-12 w-12 rounded-full shadow-lg"
              data-testid="button-floating-calc"
            >
              <CalcIcon className="h-6 w-6" />
            </Button>
            <Button
              onClick={() => setShowChatbot(true)}
              size="icon"
              className="h-12 w-12 rounded-full shadow-lg"
              data-testid="button-floating-chat"
            >
              <MessageCircle className="h-6 w-6" />
            </Button>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="fixed bottom-6 right-6 z-50 flex gap-2">
      <Button
        onClick={() => setShowCalculator(true)}
        size="icon"
        className="h-12 w-12 rounded-full shadow-lg hover:scale-110 transition-transform"
        data-testid="button-floating-calc"
        title="Calculator"
      >
        <CalcIcon className="h-6 w-6" />
      </Button>
      <Button
        onClick={() => setShowChatbot(true)}
        size="icon"
        className="h-12 w-12 rounded-full shadow-lg hover:scale-110 transition-transform"
        data-testid="button-floating-chat"
        title="AI Assistant"
      >
        <MessageCircle className="h-6 w-6" />
      </Button>
    </div>
  );
}
