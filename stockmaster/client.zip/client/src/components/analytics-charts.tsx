import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

const stockTrendData = [
  { month: "Jul", inStock: 856, lowStock: 12, outOfStock: 3 },
  { month: "Aug", inStock: 924, lowStock: 18, outOfStock: 5 },
  { month: "Sep", inStock: 1053, lowStock: 15, outOfStock: 2 },
  { month: "Oct", inStock: 1124, lowStock: 20, outOfStock: 7 },
  { month: "Nov", inStock: 1187, lowStock: 19, outOfStock: 4 },
  { month: "Dec", inStock: 1247, lowStock: 23, outOfStock: 6 },
];

const categoryData = [
  { category: "Electronics", items: 487 },
  { category: "Furniture", items: 234 },
  { category: "Stationery", items: 356 },
  { category: "Tools", items: 178 },
  { category: "Other", items: 92 },
];

const stockStatusData = [
  { name: "In Stock", value: 1247, color: "hsl(var(--chart-1))" },
  { name: "Low Stock", value: 23, color: "hsl(var(--chart-4))" },
  { name: "Out of Stock", value: 6, color: "hsl(var(--chart-5))" },
];

const topMovingItems = [
  { name: "USB-C Cable", moves: 234 },
  { name: "Wireless Mouse", moves: 198 },
  { name: "Notebook Set", moves: 176 },
  { name: "Desk Lamp", moves: 154 },
  { name: "Monitor Stand", moves: 142 },
];

export function StockTrendChart() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Stock Levels Over Time</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={320}>
          <LineChart data={stockTrendData}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
            <XAxis dataKey="month" stroke="hsl(var(--muted-foreground))" />
            <YAxis stroke="hsl(var(--muted-foreground))" />
            <Tooltip
              contentStyle={{
                backgroundColor: "hsl(var(--popover))",
                border: "1px solid hsl(var(--popover-border))",
                borderRadius: "6px",
              }}
            />
            <Legend />
            <Line
              type="monotone"
              dataKey="inStock"
              stroke="hsl(var(--chart-1))"
              strokeWidth={2}
              name="In Stock"
            />
            <Line
              type="monotone"
              dataKey="lowStock"
              stroke="hsl(var(--chart-4))"
              strokeWidth={2}
              name="Low Stock"
            />
            <Line
              type="monotone"
              dataKey="outOfStock"
              stroke="hsl(var(--chart-5))"
              strokeWidth={2}
              name="Out of Stock"
            />
          </LineChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}

export function CategoryDistributionChart() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Category Distribution</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={320}>
          <BarChart data={categoryData}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
            <XAxis dataKey="category" stroke="hsl(var(--muted-foreground))" />
            <YAxis stroke="hsl(var(--muted-foreground))" />
            <Tooltip
              contentStyle={{
                backgroundColor: "hsl(var(--popover))",
                border: "1px solid hsl(var(--popover-border))",
                borderRadius: "6px",
              }}
            />
            <Bar dataKey="items" fill="hsl(var(--chart-1))" name="Items" />
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}

export function StockStatusChart() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Stock Status Breakdown</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={320}>
          <PieChart>
            <Pie
              data={stockStatusData}
              cx="50%"
              cy="50%"
              labelLine={false}
              label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
              outerRadius={100}
              fill="#8884d8"
              dataKey="value"
            >
              {stockStatusData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color} />
              ))}
            </Pie>
            <Tooltip
              contentStyle={{
                backgroundColor: "hsl(var(--popover))",
                border: "1px solid hsl(var(--popover-border))",
                borderRadius: "6px",
              }}
            />
          </PieChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}

export function TopMovingItemsChart() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Top Moving Items (Last 30 Days)</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={320}>
          <BarChart data={topMovingItems} layout="vertical">
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
            <XAxis type="number" stroke="hsl(var(--muted-foreground))" />
            <YAxis dataKey="name" type="category" stroke="hsl(var(--muted-foreground))" width={120} />
            <Tooltip
              contentStyle={{
                backgroundColor: "hsl(var(--popover))",
                border: "1px solid hsl(var(--popover-border))",
                borderRadius: "6px",
              }}
            />
            <Bar dataKey="moves" fill="hsl(var(--chart-2))" name="Transactions" />
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}
