import { Link } from "wouter";
import { Package } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ThemeToggle } from "@/components/theme-toggle";

export function Navbar() {
  return (
    <nav className="border-b bg-background sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link href="/">
            <div className="flex items-center gap-2 cursor-pointer">
              <div className="h-8 w-8 rounded-md bg-primary flex items-center justify-center">
                <Package className="h-5 w-5 text-primary-foreground" />
              </div>
              <span className="text-xl font-bold">StockMaster</span>
            </div>
          </Link>

          {/* Navigation Tabs */}
          <div className="hidden md:flex items-center gap-8">
            <Link href="/">
              <a className="text-muted-foreground hover:text-foreground transition-colors">Features</a>
            </Link>
            <Link href="/">
              <a className="text-muted-foreground hover:text-foreground transition-colors">Solutions</a>
            </Link>
            <Link href="/">
              <a className="text-muted-foreground hover:text-foreground transition-colors">Pricing</a>
            </Link>
          </div>

          {/* Right Side Actions */}
          <div className="flex items-center gap-4">
            <ThemeToggle />
            <Link href="/login">
              <Button variant="outline" size="sm" data-testid="button-login">
                Login
              </Button>
            </Link>
            <Link href="/signup">
              <Button size="sm" data-testid="button-signup">
                Sign Up
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
}
