import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Send, X } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";

interface Message {
  id: string;
  text: string;
  sender: "user" | "bot";
  timestamp: Date;
}

interface ChatbotProps {
  onClose?: () => void;
}

const aiResponses: Record<string, string> = {
  stock: "📊 Based on current trends, I recommend increasing stock for high-demand items and reducing for slower-moving products. Focus on items with turnover rates above 4x annually. This will optimize your cash flow and storage costs.",
  low: "⚠️ To manage low stock items, implement automated reordering at 50% of minimum stock level. This ensures continuous availability while minimizing storage costs. Set up alerts for critical stock levels.",
  forecast: "📈 Analyzing historical data, I predict a 15% increase in demand next quarter. Recommend stockpiling 20% more inventory for fast-moving categories, especially in Electronics and Furniture.",
  warehouse: "🏭 Optimize warehouse operations by implementing zone-based storage for frequently accessed items. This can reduce picking time by 30% with strategic placement. Consider ABC analysis for better organization.",
  profit: "💰 Increase profitability by focusing on high-margin items. Consider bundling slow-moving items with bestsellers to improve overall sales velocity. Review pricing strategy for premium products.",
  trends: "📊 Current market trends show strong demand in Electronics (45% growth) and Furniture categories (32% growth). Suggest reallocating 30% of budget to these high-opportunity segments.",
  capacity: "📦 Your warehouse is operating at 71% capacity across 3 locations. Mumbai (75%), Delhi (80%), Bangalore (66%). Recommend inventory rebalancing or planning for expansion.",
  optimization: "⚡ Quick wins: Implement just-in-time ordering for 20% slower items, consolidate suppliers to reduce lead times by 15%, and automate reordering for fast-moving categories.",
  default: "👋 I'm your AI Assistant! I can help with: stock optimization, low stock management, demand forecasting, warehouse operations, profitability analysis, market trends, and capacity planning. What would you like to know?",
};

function getAIResponse(message: string): string {
  const lower = message.toLowerCase();
  
  if (lower.includes("capacity") || lower.includes("space") || lower.includes("warehouse")) return aiResponses.capacity;
  if (lower.includes("optim") || lower.includes("improve") || lower.includes("efficiency")) return aiResponses.optimization;
  if (lower.includes("stock") || lower.includes("inventory")) return aiResponses.stock;
  if (lower.includes("low") || lower.includes("minimum") || lower.includes("reorder")) return aiResponses.low;
  if (lower.includes("forecast") || lower.includes("predict") || lower.includes("demand")) return aiResponses.forecast;
  if (lower.includes("warehouse") || lower.includes("storage") || lower.includes("location")) return aiResponses.warehouse;
  if (lower.includes("profit") || lower.includes("margin") || lower.includes("revenue")) return aiResponses.profit;
  if (lower.includes("trend") || lower.includes("market") || lower.includes("category")) return aiResponses.trends;
  
  return aiResponses.default;
}

export function AIChatbot({ onClose }: ChatbotProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      text: "Hello! I'm your AI Assistant. I can help you with inventory management, forecasting, and decision-making. What would you like to know?",
      sender: "bot",
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSendMessage = async () => {
    if (!input.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text: input,
      sender: "user",
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setLoading(true);

    setTimeout(() => {
      const botResponse: Message = {
        id: (Date.now() + 1).toString(),
        text: getAIResponse(input),
        sender: "bot",
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, botResponse]);
      setLoading(false);
    }, 500);
  };

  return (
    <div className="w-full max-w-md flex flex-col h-[500px] bg-white dark:bg-slate-950 rounded-xl shadow-2xl border border-slate-200 dark:border-slate-700 overflow-hidden">
      <div className="flex items-center justify-between p-4 bg-gradient-to-r from-blue-500 to-purple-600 border-b border-blue-600">
        <h2 className="text-white font-bold text-lg flex items-center gap-2">
          🤖 AI Management Advisor
        </h2>
        {onClose && (
          <Button variant="ghost" size="icon" onClick={onClose} data-testid="button-close-chat" className="text-white hover:bg-white/20">
            <X className="h-4 w-4" />
          </Button>
        )}
      </div>
      <div className="flex-1 flex flex-col gap-3 p-4 bg-slate-50 dark:bg-slate-900">
        <ScrollArea className="flex-1 pr-3 space-y-3">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex ${msg.sender === "user" ? "justify-end" : "justify-start"}`}
            >
              <div
                className={`max-w-xs px-4 py-3 rounded-xl text-sm font-medium leading-relaxed ${
                  msg.sender === "user"
                    ? "bg-blue-500 text-white rounded-bl-none shadow-md"
                    : "bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-tl-none shadow-sm"
                }`}
                data-testid={`message-${msg.sender}`}
              >
                <p>{msg.text}</p>
              </div>
            </div>
          ))}
          {loading && (
            <div className="flex justify-start">
              <div className="bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 rounded-tl-none">
                <div className="flex gap-2 items-center">
                  <span className="text-xs">Thinking</span>
                  <div className="flex gap-1">
                    <div className="h-2 w-2 rounded-full bg-blue-500 animate-bounce"></div>
                    <div className="h-2 w-2 rounded-full bg-blue-500 animate-bounce" style={{ animationDelay: "0.1s" }}></div>
                    <div className="h-2 w-2 rounded-full bg-blue-500 animate-bounce" style={{ animationDelay: "0.2s" }}></div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </ScrollArea>

        <div className="flex gap-2 pt-2 border-t border-slate-200 dark:border-slate-700">
          <Input
            placeholder="Ask for recommendations..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
            disabled={loading}
            className="bg-white dark:bg-slate-800 border-slate-300 dark:border-slate-600"
            data-testid="input-chat-message"
          />
          <Button
            onClick={handleSendMessage}
            disabled={loading || !input.trim()}
            size="icon"
            className="bg-blue-500 hover:bg-blue-600 text-white"
            data-testid="button-send-message"
          >
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
