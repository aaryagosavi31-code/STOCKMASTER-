import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { AlertTriangle, CheckCircle2, XCircle } from "lucide-react";
import { cn } from "@/lib/utils";

export interface Alert {
  id: string;
  type: "low_stock" | "out_of_stock" | "reorder";
  itemName: string;
  sku: string;
  currentStock: number;
  minStock: number;
  timestamp: string;
  severity: "high" | "medium" | "low";
}

interface AlertListProps {
  alerts: Alert[];
  onResolve?: (alert: Alert) => void;
  onDismiss?: (alert: Alert) => void;
}

export function AlertList({ alerts, onResolve, onDismiss }: AlertListProps) {
  const getSeverityColor = (severity: Alert["severity"]) => {
    switch (severity) {
      case "high":
        return "bg-red-100 dark:bg-red-900/20 text-red-600";
      case "medium":
        return "bg-yellow-100 dark:bg-yellow-900/20 text-yellow-600";
      case "low":
        return "bg-blue-100 dark:bg-blue-900/20 text-blue-600";
    }
  };

  const getAlertMessage = (alert: Alert) => {
    if (alert.type === "out_of_stock") {
      return `Out of stock - Immediate action required`;
    }
    if (alert.type === "low_stock") {
      return `Low stock (${alert.currentStock} remaining, min: ${alert.minStock})`;
    }
    return `Reorder point reached`;
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between gap-4 flex-wrap">
          <CardTitle>Stock Alerts</CardTitle>
          <Badge variant="secondary">{alerts.length} Active</Badge>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {alerts.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <CheckCircle2 className="h-12 w-12 mx-auto mb-2 text-green-600" />
              <p>No active alerts. All stock levels are healthy!</p>
            </div>
          ) : (
            alerts.map((alert, index) => (
              <div
                key={alert.id}
                className={cn(
                  "flex items-start gap-4 pb-4",
                  index !== alerts.length - 1 && "border-b"
                )}
                data-testid={`alert-${alert.id}`}
              >
                <div
                  className={cn(
                    "h-10 w-10 rounded-md flex items-center justify-center flex-shrink-0",
                    getSeverityColor(alert.severity)
                  )}
                >
                  {alert.type === "out_of_stock" ? (
                    <XCircle className="h-5 w-5" />
                  ) : (
                    <AlertTriangle className="h-5 w-5" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2 flex-wrap mb-1">
                    <div className="flex-1 min-w-0">
                      <p className="font-medium truncate">{alert.itemName}</p>
                      <p className="text-sm text-muted-foreground">SKU: {alert.sku}</p>
                    </div>
                    <Badge
                      variant={
                        alert.severity === "high"
                          ? "destructive"
                          : alert.severity === "medium"
                          ? "secondary"
                          : "default"
                      }
                    >
                      {alert.severity.toUpperCase()}
                    </Badge>
                  </div>
                  <p className="text-sm mb-2">{getAlertMessage(alert)}</p>
                  <p className="text-xs text-muted-foreground mb-3">{alert.timestamp}</p>
                  <div className="flex gap-2 flex-wrap">
                    <Button
                      size="sm"
                      onClick={() => onResolve?.(alert)}
                      data-testid={`button-resolve-${alert.id}`}
                    >
                      Reorder Now
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => onDismiss?.(alert)}
                      data-testid={`button-dismiss-${alert.id}`}
                    >
                      Dismiss
                    </Button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
}
