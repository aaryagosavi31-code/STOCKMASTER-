import { createContext, useContext, useState, useEffect } from "react";
import { useTranslation } from "@/lib/i18n";

interface LanguageContextType {
  language: string;
  currency: string;
  setLanguageAndCurrency: (lang: string, curr: string) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguage] = useState(() => {
    return localStorage.getItem("language") || "en";
  });
  const [currency, setCurrency] = useState(() => {
    return localStorage.getItem("currency") || "USD";
  });

  // Map en-inr to en for translation purposes
  const translationLang = language.startsWith("en-inr") ? "en" : language;
  const t = useTranslation(translationLang);

  const setLanguageAndCurrency = (lang: string, curr: string) => {
    setLanguage(lang);
    setCurrency(curr);
    localStorage.setItem("language", lang);
    localStorage.setItem("currency", curr);
    window.dispatchEvent(new CustomEvent("languageChange", { detail: { lang, curr } }));
  };

  useEffect(() => {
    const handleLanguageChange = (e: any) => {
      setLanguage(e.detail.lang);
      setCurrency(e.detail.curr);
    };
    window.addEventListener("languageChange", handleLanguageChange);
    return () => window.removeEventListener("languageChange", handleLanguageChange);
  }, []);

  const tFunction = ((key: string) => t(key as any)) as (key: string) => string;

  return (
    <LanguageContext.Provider value={{ language, currency, setLanguageAndCurrency, t: tFunction }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    // Fallback for when not wrapped in provider
    let lang = localStorage.getItem("language") || "en";
    let curr = localStorage.getItem("currency") || "USD";
    
    // Map en-inr to en for translation purposes
    const translationLang = lang.startsWith("en-inr") ? "en" : lang;
    const t = useTranslation(translationLang);
    return { language: lang, currency: curr, setLanguageAndCurrency: () => {}, t };
  }
  return context;
}
